// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static n_bool     n_nyaurism_plotter_selection_reverse = n_false;
static n_bool     n_nyaurism_plotter_selection_insert  = n_false;
static n_type_gfx n_nyaurism_plotter_selection_from    = 0;
static n_type_gfx n_nyaurism_plotter_selection_loop    = 0;
static n_type_gfx n_nyaurism_plotter_selection_size    = 0;
static n_type_gfx n_nyaurism_plotter_selection_step    = 0;
static n_wav      n_nyaurism_plotter_selection_clip;




#define n_nyaurism_plotter_redraw( h ) n_nyaurism_plotter_draw( h, -1 )

// internal
void
n_nyaurism_plotter_draw( HWND hgui, int seek_msec )
{
//return;

	if ( n_wav_error_format( &n_nyaurism_wav ) ) { return; }


	const u32  color_l = n_bmp_rgb(   0,200,255 );
	const u32  color_r = n_bmp_rgb(   0,255,200 );
	const u32  color_i = n_bmp_rgb( 255,  0,150 );
	const u32  c_grid1 = n_bmp_rgb(  50, 50, 50 );
	const u32  c_grid2 = n_bmp_rgb(   0,100,100 );
	const u32  cselect = n_bmp_rgb( 255,255,255 );


	const n_bool seekbar = ( seek_msec != -1 );


	n_type_gfx sx,sy; n_win_size( hgui, &sx, &sy );

	sx = n_posix_max_n_type_gfx( 1, sx );
	sy = n_posix_max_n_type_gfx( 1, sy );


	const n_type_gfx  count  = (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav );
	const n_type_real per_ms = N_WAV_RATE ( &n_nyaurism_wav ) / 1000;

	n_type_gfx  unit_x  = sx;
	n_type_gfx  unit_y  = sy / 4;
	n_type_gfx  line_l  = unit_y * 1;
	n_type_gfx  line_r  = unit_y * 3;
	n_type_real ratio_x = (n_type_real) unit_x /     count;
	n_type_real ratio_y = (n_type_real) unit_y / N_WAV_AMP;
	n_type_gfx  seek_x  = (n_type_gfx) ( (n_type_real) ( seek_msec * per_ms ) * ratio_x );
	n_type_gfx  step_x  = n_posix_max_n_type_gfx( 1, count / unit_x );


	n_nyaurism_plotter_selection_step = step_x;


	n_type_gfx grid_sx = sx;//(n_type_real) ratio_x * ( per_ms    * 10  );
	n_type_gfx grid_sy = (n_type_gfx) ( (n_type_real) ratio_y * ( N_WAV_AMP * 0.1 ) );

	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, grid_sx,grid_sy );
	n_bmp_flush( &bmp, c_grid1 );
	n_bmp_box( &bmp, 1,1,grid_sx-2,grid_sy-2, n_bmp_black );

	n_bmp_resizer( &bmp, sx,sy, 0, N_BMP_RESIZER_TILE );


	n_type_gfx grid_1 = (n_type_gfx) ( (n_type_real) (   10 * per_ms ) * ratio_x );
	n_type_gfx grid_2 = (n_type_gfx) ( (n_type_real) ( 1000 * per_ms ) * ratio_x );


	n_type_gfx x = 0;
	n_posix_loop
	{

		n_type_gfx pos = x * step_x;
		if ( pos >= count ) { break; }


		// [!] : threshold is 4px

		if ( ( grid_1 >= 4 )&&( 0 == ( x % grid_1 ) ) )
		{
			n_bmp_box( &bmp, x,0, 1,sy, c_grid1 );
		} else
		if ( ( grid_2 >= 4 )&&( 0 == ( x % grid_2 ) ) )
		{
			n_bmp_box( &bmp, x,0, 1,sy, c_grid2 );
		}


		n_type_real l,r; n_wav_sample_get( &n_nyaurism_wav, pos, &l, &r );


		// [!] : ( n * -1 ) : up-side-down : WAV to BMP

		n_type_gfx ty_l = (n_type_gfx) ( line_l + trunc( l * ratio_y * -1 ) );
		n_type_gfx ty_r = (n_type_gfx) ( line_r + trunc( r * ratio_y * -1 ) );

		n_type_gfx fy_l = line_l;
		n_posix_loop
		{
			n_bmp_ptr_set( &bmp, x,fy_l, color_l );
			if ( fy_l == ty_l ) { break; }
			if ( fy_l > ty_l ) { fy_l--; } else { fy_l++; }
		}

		n_type_gfx fy_r = line_r;
		n_posix_loop
		{
			n_bmp_ptr_set( &bmp, x,fy_r, color_r );
			if ( fy_r == ty_r ) { break; }
			if ( fy_r > ty_r ) { fy_r--; } else { fy_r++; }
		}

/*
		n_type_int i = 0;
		n_posix_loop
		{

			n_type_gfx y_l = line_l + trunc( (n_type_real) ptr[ pos + i + 0 ] * unit );
			n_type_gfx y_r = line_r + trunc( (n_type_real) ptr[ pos + i + 1 ] * unit );

			n_bmp_ptr_set( &bmp, x,y_l, color_l );
			n_bmp_ptr_set( &bmp, x,y_r, color_r );

			i++;
			if ( i >= step_x ) { break; }
		}
*/

		x++;
		if ( x >= sx ) { break; }
	}


	{
		n_type_gfx from;
		if ( n_nyaurism_plotter_selection_reverse )
		{
			from = n_nyaurism_plotter_selection_loop;
		} else {
			from = n_nyaurism_plotter_selection_from;
		}

		n_type_gfx size = n_nyaurism_plotter_selection_size;
		if ( n_nyaurism_plotter_selection_insert )
		{
			size = 1;
		}

		n_bmp_mixer( &bmp, from, 0, size, sy, cselect, 0.2 );

		if ( from != 0 )
		{
			n_bmp_line( &bmp, from, 0, from, sy, cselect );
		}

		if ( size >= 2 )
		{
			n_bmp_line( &bmp, from + size, 0, from + size, sy, cselect );
		}
	}


	if ( seekbar )
	{
		n_bmp_box( &bmp, seek_x-1,0, 1,sy, color_i );
	}


	// Redraw

	n_gdi_bitmap_draw( hgui, &bmp, 0,0,sx,sy, 0,0 );


	n_bmp_free( &bmp );


	return;
}

void
n_nyaurism_plotter_selection_off( void )
{
//return;

	n_nyaurism_plotter_selection_from = 0;
	n_nyaurism_plotter_selection_loop = 0;
	n_nyaurism_plotter_selection_size = 0;


	return;
}

void
n_nyaurism_plotter_selection_pixel2sample( n_type_gfx *ret_x, n_type_gfx *ret_sx )
{
//return;

	n_type_gfx x;
	if ( n_nyaurism_plotter_selection_reverse )
	{
		x = n_nyaurism_plotter_selection_step * n_nyaurism_plotter_selection_loop;
	} else {
		x = n_nyaurism_plotter_selection_step * n_nyaurism_plotter_selection_from;
	}
	n_type_gfx sx = n_nyaurism_plotter_selection_step * n_nyaurism_plotter_selection_size;

	if ( x < 0 ) { sx += x; x = 0; }
	if ( ( x + sx ) >= (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav ) ) { sx = (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav ) - x; }


	if ( ret_x  != NULL ) { (*ret_x ) =  x; }
	if ( ret_sx != NULL ) { (*ret_sx) = sx; }


	return;
}

#define N_NYAURISM_PLOTTER_MENU_MUTE   0
#define N_NYAURISM_PLOTTER_MENU_CUT    1
#define N_NYAURISM_PLOTTER_MENU_COPY   2
#define N_NYAURISM_PLOTTER_MENU_PASTE  3
#define N_NYAURISM_PLOTTER_MENU_DELETE 4
#define N_NYAURISM_PLOTTER_MENU_INSERT 5

void
n_nyaurism_plotter_menu_init( n_win_simplemenu *p )
{
//return;

	n_win_simplemenu_set( p, N_NYAURISM_PLOTTER_MENU_MUTE  , NULL, n_posix_literal( "[ ]Mute"   ), NULL );
	n_win_simplemenu_set( p, N_NYAURISM_PLOTTER_MENU_CUT   , NULL, n_posix_literal( "[ ]Cut"    ), NULL );
	n_win_simplemenu_set( p, N_NYAURISM_PLOTTER_MENU_COPY  , NULL, n_posix_literal( "[ ]Copy"   ), NULL );
	n_win_simplemenu_set( p, N_NYAURISM_PLOTTER_MENU_PASTE , NULL, n_posix_literal( "[ ]Paste"  ), NULL );
	n_win_simplemenu_set( p, N_NYAURISM_PLOTTER_MENU_DELETE, NULL, n_posix_literal( "[ ]Delete" ), NULL );
	n_win_simplemenu_set( p, N_NYAURISM_PLOTTER_MENU_INSERT, NULL, n_posix_literal( "[ ]Insert" ), NULL );


	return;
}

void
n_nyaurism_plotter_menu_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, n_win_simplemenu *p )
{
//return;

	if ( msg != WM_COMMAND ) { return; }

	if ( (HWND) lparam != p->hwnd ) { return; }

	if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
	{

		n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_MUTE  , ' ' );
		n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_CUT   , ' ' );
		n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_COPY  , ' ' );
		n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_PASTE , ' ' );
		n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_DELETE, ' ' );
		n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_INSERT, ' ' );


		n_type_gfx sz; n_win_size( hgui, &sz, NULL );
		n_type_int size = (n_type_int) sz;

		if ( size == n_nyaurism_plotter_selection_size )
		{
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_CUT   , 'x' );
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_DELETE, 'x' );
		}


		if ( n_nyaurism_plotter_selection_size == 0 )
		{
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_MUTE  , 'x' );
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_CUT   , 'x' );
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_COPY  , 'x' );
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_PASTE , 'x' );
			n_win_simplemenu_tweak_literal( p, N_NYAURISM_PLOTTER_MENU_DELETE, 'x' );
		}

	} else
	if ( wparam == N_NYAURISM_PLOTTER_MENU_MUTE )
	{

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Mute : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

		n_wav_mute( &n_nyaurism_wav, x, sx );

		n_nyaurism_plotter_selection_off();

		n_nyaurism_plotter_redraw( hgui );

	} else
	if ( wparam == N_NYAURISM_PLOTTER_MENU_CUT )
	{

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Cut : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

		n_wav_new_by_sample( &n_nyaurism_plotter_selection_clip, sx );
		n_wav_copy( &n_nyaurism_wav, &n_nyaurism_plotter_selection_clip, x,sx, 0, 1.0,1.0, N_WAV_COPY_SET );
		n_wav_delete( &n_nyaurism_wav, x, sx );

		n_nyaurism_plotter_selection_off();

		n_nyaurism_plotter_redraw( hgui );

	} else
	if ( wparam == N_NYAURISM_PLOTTER_MENU_COPY )
	{

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Copy : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

		n_wav_new_by_sample( &n_nyaurism_plotter_selection_clip, sx );
		n_wav_copy( &n_nyaurism_wav, &n_nyaurism_plotter_selection_clip, x,sx, 0, 1.0,1.0, N_WAV_COPY_SET );

		n_nyaurism_plotter_selection_off();

		n_nyaurism_plotter_redraw( hgui );

	} else
	if ( wparam == N_NYAURISM_PLOTTER_MENU_PASTE )
	{

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Paste : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

		int option;
		if ( n_nyaurism_mix_onoff )
		{
			option = N_WAV_COPY_ADD;
		} else {
			option = N_WAV_COPY_SET;
		}
		n_wav_copy( &n_nyaurism_plotter_selection_clip, &n_nyaurism_wav, 0,0, x, 1.0,1.0, option );

		n_nyaurism_plotter_selection_off();

		n_nyaurism_plotter_redraw( hgui );

	} else
	if ( wparam == N_NYAURISM_PLOTTER_MENU_DELETE )
	{

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Delete : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

		n_wav_delete( &n_nyaurism_wav, x, sx );

		n_nyaurism_plotter_selection_off();

		n_nyaurism_plotter_redraw( hgui );

	} else
	if ( wparam == N_NYAURISM_PLOTTER_MENU_INSERT )
	{

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Insert : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

		n_wav_insert( &n_nyaurism_wav, &n_nyaurism_plotter_selection_clip, x, sx );

		n_nyaurism_plotter_selection_off();

		n_nyaurism_plotter_redraw( hgui );

	}


	return;
}

void
n_nyaurism_plotter_selection_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, n_win_simplemenu *p )
{
//return;

	static n_bool onoff = n_false;


	switch( msg ) {


	case WM_LBUTTONDBLCLK :

		if ( n_false == n_win_is_hovered( hgui ) ) { break; }

		{

			n_type_gfx size;
			if ( n_nyaurism_plotter_selection_step == 1 )
			{
				size = (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav );
			} else {
				n_type_gfx sz; n_win_size( hgui, &sz, NULL );
				size = (n_type_int) sz;
			}

			n_nyaurism_plotter_selection_from =    0;
			n_nyaurism_plotter_selection_loop =    0;
			n_nyaurism_plotter_selection_size = size;

			n_nyaurism_plotter_redraw( hgui );

		}

	break;

	case WM_LBUTTONDOWN :
//n_win_hwndprintf_literal( hwnd, " WM_LBUTTONDOWN " );

		if ( n_false == n_win_is_hovered( hgui ) ) { break; }

		if ( onoff == n_false )
		{

			n_type_gfx cursor; n_win_cursor_position_relative( hgui, &cursor, NULL );

			if ( ( n_nyaurism_plotter_selection_step == 1 )&&( cursor >(n_type_gfx)  N_WAV_COUNT( &n_nyaurism_wav ) ) )
			{
				n_nyaurism_plotter_selection_off();
				n_nyaurism_plotter_redraw( hgui );

				break;
			}
			n_nyaurism_plotter_selection_from = cursor;

			SetCapture( hwnd );

			onoff = n_true;

//n_win_hwndprintf_literal( hwnd, " %d ", n_nyaurism_plotter_selection_from );
		}

	break;

	case WM_LBUTTONUP :

		if ( onoff )
		{

			onoff = n_false;

			n_type_gfx cursor; n_win_cursor_position_relative( hgui, &cursor, NULL );

			if ( cursor < n_nyaurism_plotter_selection_from )
			{
				n_nyaurism_plotter_selection_from = n_nyaurism_plotter_selection_loop;
			} else
			if ( cursor == n_nyaurism_plotter_selection_from )
			{
				n_nyaurism_plotter_selection_off();
			}

			ReleaseCapture();

			n_nyaurism_plotter_redraw( hgui );

		}

	break;

	case WM_MOUSEMOVE :

		if ( onoff )
		{

			n_type_gfx cursor; n_win_cursor_position_relative( hgui, &cursor, NULL );

			if ( cursor < 0 ) { cursor = 0; }

			if ( ( n_nyaurism_plotter_selection_step == 1 )&&( cursor > (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav ) ) )
			{
				if ( n_nyaurism_plotter_selection_reverse )
				{
					n_nyaurism_plotter_selection_size = (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav ) - n_nyaurism_plotter_selection_loop;
				} else {
					n_nyaurism_plotter_selection_size = (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav ) - n_nyaurism_plotter_selection_from;
				}
			} else
			if ( cursor < n_nyaurism_plotter_selection_from )
			{
				n_nyaurism_plotter_selection_reverse =  n_true;

				n_nyaurism_plotter_selection_size = n_nyaurism_plotter_selection_from - cursor;
				n_nyaurism_plotter_selection_loop = cursor;
			} else {
				n_nyaurism_plotter_selection_reverse = n_false;

				n_type_gfx size; n_win_size( hgui, &size, NULL );

				n_nyaurism_plotter_selection_size = n_posix_min_n_type_gfx( size, cursor - n_nyaurism_plotter_selection_from );
			}

			n_nyaurism_plotter_redraw( hgui );

//n_win_hwndprintf_literal( hwnd, " %d %d ", n_nyaurism_plotter_selection_from, n_nyaurism_plotter_selection_size );
		}

	break;


	case WM_RBUTTONDOWN :

		if ( n_false == n_win_is_hovered( hgui ) ) { break; }

		if ( n_nyaurism_plotter_selection_size == 0 )
		{

			n_type_gfx cursor; n_win_cursor_position_relative( hgui, &cursor, NULL );

			if ( ( n_nyaurism_plotter_selection_step == 1 )&&( cursor > (n_type_gfx) N_WAV_COUNT( &n_nyaurism_wav ) ) )
			{
				//
			} else {
				n_nyaurism_plotter_selection_from = cursor;

				n_nyaurism_plotter_selection_insert = n_true;
				n_nyaurism_plotter_redraw( hgui );
			}

		}

	break;

	case WM_RBUTTONUP :
//n_win_hwndprintf_literal( hwnd, " WM_RBUTTONDOWN " );

		if ( n_false == n_win_is_hovered( hgui ) ) { break; }

		n_win_simplemenu_show( p, hwnd );

		n_nyaurism_plotter_selection_insert = n_false;
		n_nyaurism_plotter_redraw( hgui );

	break;


	case WM_SIZE :

		// [!] : currently not supported

		n_nyaurism_plotter_selection_off();

	break;


	} // switch


	return;
}


