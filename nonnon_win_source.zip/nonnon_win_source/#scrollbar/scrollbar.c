// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"


#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_scrollbar.c"


#include "../nonnon/project/macro.c"




#define N_SCROLLBAR_SCALE ( 2 )




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_scrollbar sc[ 5 ];

	static n_posix_bool is_horz = n_posix_true;


	switch( msg ) {


	case WM_CREATE :


		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		n_game_timegettime_init();


		n_win_init_literal( hwnd, "Scrollbar", "MAIN_ICON", "" );

		{
			n_type_gfx size = 256 * N_SCROLLBAR_SCALE;

			n_win_style_new( hwnd, N_WS_FIXEDWINDOW );
			n_win_set( hwnd, NULL, size,size, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );
		}


		{

			n_win_scrollbar_zero( &sc[ 0 ] );
			n_win_scrollbar_zero( &sc[ 1 ] );
			n_win_scrollbar_zero( &sc[ 2 ] );
			n_win_scrollbar_zero( &sc[ 3 ] );
			n_win_scrollbar_zero( &sc[ 4 ] );

			int layout = N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL;

			int opt2  = N_WIN_SCROLLBAR_OPTION_PAGER;
			    opt2 |= N_WIN_SCROLLBAR_OPTION_NO_ARROWS;

			int style4 = N_WIN_SCROLLBAR_STYLE_STRIPE | N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND;

			n_win_scrollbar_init( &sc[ 0 ], hwnd, layout, N_WIN_SCROLLBAR_STYLE_CLASSIC     ,    0 );
			n_win_scrollbar_init( &sc[ 1 ], hwnd, layout, N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT,    0 );
			n_win_scrollbar_init( &sc[ 2 ], hwnd, layout, N_WIN_SCROLLBAR_STYLE_SOLID       , opt2 );
			n_win_scrollbar_init( &sc[ 3 ], hwnd, layout, N_WIN_SCROLLBAR_STYLE_VISUALSTYLE ,    0 );
			n_win_scrollbar_init( &sc[ 4 ], hwnd, layout, style4                            ,    0 );

			sc[ 0 ].scale = N_SCROLLBAR_SCALE;
			sc[ 1 ].scale = N_SCROLLBAR_SCALE;
			sc[ 2 ].scale = N_SCROLLBAR_SCALE;
			sc[ 3 ].scale = N_SCROLLBAR_SCALE;
			sc[ 4 ].scale = N_SCROLLBAR_SCALE;

		}


		n_win_message_send( hwnd, WM_SIZE, 0, 0 );

		n_win_scrollbar_parameter( &sc[ 0 ], 1, 80, 200, 100, n_posix_false );
		n_win_scrollbar_parameter( &sc[ 1 ], 1, 80, 200, 100, n_posix_false );
		n_win_scrollbar_parameter( &sc[ 2 ], 1, 80, 200, 100, n_posix_false );
		n_win_scrollbar_parameter( &sc[ 3 ], 1, 80, 200, 100, n_posix_false );
		n_win_scrollbar_parameter( &sc[ 4 ], 1, 80, 200, 100, n_posix_false );
//n_bmp_save_literal( &sc[ 4 ].bmp_dr, "dr.bmp" );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		// [Needed] : N_WIN_SET_CALCONLY : for VC++ 2017
		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

		n_type_gfx sx,sy;
		if ( is_horz )
		{
			sx = 200;
			sy = n_win_scrollbar_stdsize( &sc[ 0 ] ) * sc[ 0 ].scale;
		} else {
			sx = n_win_scrollbar_stdsize( &sc[ 0 ] ) * sc[ 0 ].scale;
			sy = 200;
		}

		n_type_gfx x,y;
		if ( is_horz )
		{
			x = ( w.csx - sx ) / 2;
			y =   w.csy        / 11;
		} else {
			x =   w.csx        / 11;
			y = ( w.csy - sy ) / 2;
		}

		if ( is_horz )
		{
			n_win_scrollbar_move( &sc[ 0 ], x, y * 1, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 1 ], x, y * 3, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 2 ], x, y * 5, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 3 ], x, y * 7, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 4 ], x, y * 9, sx,sy, n_posix_true );
		} else {
			n_win_scrollbar_move( &sc[ 0 ], x * 1, y, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 1 ], x * 3, y, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 2 ], x * 5, y, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 3 ], x * 7, y, sx,sy, n_posix_true );
			n_win_scrollbar_move( &sc[ 4 ], x * 9, y, sx,sy, n_posix_true );
		}

	}
	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{

			static n_posix_bool enabled = n_posix_true;

			if ( enabled )
			{
				enabled = n_posix_false;
			} else {
				enabled = n_posix_true;
			}

			n_win_scrollbar_enable( &sc[ 0 ], enabled, n_posix_true );
			n_win_scrollbar_enable( &sc[ 1 ], enabled, n_posix_true );
			n_win_scrollbar_enable( &sc[ 2 ], enabled, n_posix_true );
			n_win_scrollbar_enable( &sc[ 3 ], enabled, n_posix_true );
			n_win_scrollbar_enable( &sc[ 4 ], enabled, n_posix_true );

		} else
		if ( wparam == VK_F2 )
		{

			int layout;
			if ( is_horz )
			{
				is_horz = n_posix_false;
				layout  = N_WIN_SCROLLBAR_LAYOUT_VERTICAL;
			} else {
				is_horz = n_posix_true;
				layout  = N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL;
			}

			sc[ 0 ].layout = layout;
			sc[ 1 ].layout = layout;
			sc[ 2 ].layout = layout;
			sc[ 3 ].layout = layout;
			sc[ 4 ].layout = layout;

			sc[ 0 ].scale  = N_SCROLLBAR_SCALE;
			sc[ 1 ].scale  = N_SCROLLBAR_SCALE;
			sc[ 2 ].scale  = N_SCROLLBAR_SCALE;
			sc[ 3 ].scale  = N_SCROLLBAR_SCALE;
			sc[ 4 ].scale  = N_SCROLLBAR_SCALE;

			n_win_message_send( hwnd, WM_SIZE, 0,0 );

			n_win_scrollbar_parameter( &sc[ 0 ], 1, 80, 200, 100, n_posix_false );
			n_win_scrollbar_parameter( &sc[ 1 ], 1, 80, 200, 100, n_posix_false );
			n_win_scrollbar_parameter( &sc[ 2 ], 1, 80, 200, 100, n_posix_false );
			n_win_scrollbar_parameter( &sc[ 3 ], 1, 80, 200, 100, n_posix_false );
			n_win_scrollbar_parameter( &sc[ 4 ], 1, 80, 200, 100, n_posix_false );

		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == sc[ 0 ].hwnd )
		{
			n_win_scrollbar_draw( &sc[ 0 ] );
			n_win_hwndprintf_literal( hwnd, " 0 : %d ", wparam );
		} else
		if ( (HWND) lparam == sc[ 1 ].hwnd )
		{
			n_win_scrollbar_draw( &sc[ 1 ] );
			n_win_hwndprintf_literal( hwnd, " 1 : %d ", wparam );
		} else
		if ( (HWND) lparam == sc[ 2 ].hwnd )
		{
			n_win_scrollbar_draw( &sc[ 2 ] );
			n_win_hwndprintf_literal( hwnd, " 2 : %d ", wparam );
		} else
		if ( (HWND) lparam == sc[ 3 ].hwnd )
		{
			n_win_scrollbar_draw( &sc[ 3 ] );
			n_win_hwndprintf_literal( hwnd, " 3 : %d ", wparam );
		} else
		if ( (HWND) lparam == sc[ 4 ].hwnd )
		{
			n_win_scrollbar_draw( &sc[ 4 ] );
			n_win_hwndprintf_literal( hwnd, " 4 : %d ", wparam );
		}// else

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_scrollbar_exit( &sc[ 0 ] );
		n_win_scrollbar_exit( &sc[ 1 ] );
		n_win_scrollbar_exit( &sc[ 2 ] );
		n_win_scrollbar_exit( &sc[ 3 ] );
		n_win_scrollbar_exit( &sc[ 4 ] );

		n_game_timegettime_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &sc[ 0 ] );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &sc[ 1 ] );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &sc[ 2 ] );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &sc[ 3 ] );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &sc[ 4 ] );

	n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &sc[ 0 ] );
	n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &sc[ 1 ] );
	n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &sc[ 2 ] );
	n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &sc[ 3 ] );
	n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &sc[ 4 ] );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


