// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/midi.c"
#include "../nonnon/neutral/random.c"




void
n_midi_random( void )
{

	const int           notes_max = 12;
	const n_posix_char *notes[]   = {

		n_posix_literal( "c " ),
		n_posix_literal( "c+" ),
		n_posix_literal( "d " ),
		n_posix_literal( "d+" ),
		n_posix_literal( "e " ),
		n_posix_literal( "f " ),
		n_posix_literal( "f+" ),
		n_posix_literal( "g " ),
		n_posix_literal( "g+" ),
		n_posix_literal( "a " ),
		n_posix_literal( "a+" ),
		n_posix_literal( "b " )

	};

	const int note_limit_oct     =  12;
	const int note_limit_oct_min =   2;
	const int note_limit_oct_max =   4;
	const int note_limit_min     = note_limit_oct * note_limit_oct_min;
	const int note_limit_max     = note_limit_oct * note_limit_oct_max;
	const int note_limit_rng     = note_limit_max - note_limit_min;

	const int note_max     = 8;
	const int note_table[] = {

		 1,
		-1,
		 2,
		-2,
		 3,
		-3,
		 6,
		-6,

	};


	// [!] : time keeper channel will be excluded

	const int channel_max = 16 - 1;

	const int         bar = 96;
	const int   delta_max = bar * 20;

	const int time_max     = 5;
	const int time_table[] = {

		24 * 4,
		24 * 2,
		24 / 1,
		24 / 3,
		24 / 4,

	};


	// [!] : start

	n_posix_char *fname = n_string_path_tmpname_new_literal( ".txt" );

	FILE *fp = n_posix_fopen_write( fname );
	if ( fp == NULL ) { n_string_path_free( fname ); return; }


	n_random_shuffle();


#ifdef UNICODE

	n_posix_fwrite( n_unicode_bom_utf16_le, sizeof( n_posix_char ), 1, fp );

#endif // #ifdef UNICODE


	n_posix_fwrite( N_STRING_CRLF, n_posix_strlen( N_STRING_CRLF ), sizeof( n_posix_char ), fp );


	// [!] : for notepad.exe in Win2000/XP

	n_posix_fwrite( N_STRING_CRLF, n_posix_strlen( N_STRING_CRLF ), sizeof( n_posix_char ), fp );


	// [!] : syncopation

	n_posix_char str[ 100 ];

	n_posix_sprintf_literal( str, "S(%1d)", (int) n_random_range( 10 ) );
	n_posix_fwrite( str, n_posix_strlen( str ), sizeof( n_posix_char ), fp );

	n_posix_fwrite( N_STRING_CRLF, n_posix_strlen( N_STRING_CRLF ), sizeof( n_posix_char ), fp );
	n_posix_fwrite( N_STRING_CRLF, n_posix_strlen( N_STRING_CRLF ), sizeof( n_posix_char ), fp );


	// [!] : delta time

	int delta[ 16 - 1 ]; n_memory_zero( delta, channel_max * sizeof( int ) );


	// [!] : main

	int ch = 0;
	int p1 = 0;
	int p2 = 0;
	int ev = 0;
	int pn = n_posix_minmax( note_limit_min, note_limit_max, n_random_range( note_limit_rng ) );
	n_posix_loop
	{

		if ( ev == 0 )
		{

			int len = n_posix_sprintf_literal( str, "C (%3d,%3d) ", ch, (int) n_random_range( 128 ) );
			n_posix_fwrite( str, len, sizeof( n_posix_char ), fp );

		} else {

			int note = pn;

			note += note_table[ n_random_range( note_max ) ];

			if (
				( note <= note_limit_min )
				||
				( note >= note_limit_max )
			)
			{
				note = n_posix_minmax( note_limit_min, note_limit_max, n_random_range( note_limit_rng ) );
			}

			pn = note;


			int n = note % notes_max;

			if ( ch != 9 )
			{
				p1 = n_posix_minmax( note_limit_oct_min, note_limit_oct_max, n );
			} else {
				p1 = n_random_range( 46 ) + 35; 
			}


			p2 = time_table[ n_random_range( time_max ) ];

			int cch = n_posix_sprintf_literal( str, "%s(%3d,%3d) ", notes[ n ], p1, p2 );
			n_posix_fwrite( str, cch, sizeof( n_posix_char ), fp );

		}

		ev++;

		delta[ ch ] += p2;
		if ( delta[ ch ] >= delta_max )
		{

			ev = 0;
			pn = n_posix_minmax( note_limit_min, note_limit_max, n_random_range( note_limit_rng ) );

			n_posix_fwrite( N_STRING_CRLF, n_posix_strlen( N_STRING_CRLF ), sizeof( n_posix_char ), fp );

			ch++;
			if ( ch >= channel_max ) { break; }
		}
	}


	n_posix_fclose( fp );


	n_midi_encode( fname, n_false );


	n_string_path_free( fname );


	return;
}

