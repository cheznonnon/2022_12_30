// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// [ Mechanism ]
//
//	[ All Version ]
//
//	a : n_catpad_flashwindow_init(), _exit() : SW_HIDE/SW_NORMAL
//	b : n_catpad_flashwindow_proc()          : WM_MOVING and WM_EXITSIZEMOVE
//
//	"b" is not needed when DWM is ON
//
//	[ Non-DWM only ]
//
//	c : n_catpad_flashwindow_proc()          : WM_KILLFOCUS and WM_SETFOCUS




void
n_catpad_flashwindow_init( void )
{

	if ( n_catpad_txtbox_onoff ) { ShowWindow( n_catpad_txtbox_editor.hwnd, SW_HIDE ); }

	return;
}

void
n_catpad_flashwindow_exit( void )
{

	if ( n_catpad_txtbox_onoff ) { ShowWindow( n_catpad_txtbox_editor.hwnd, SW_NORMAL); }

	return;
}

void
n_catpad_flashwindow_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( n_catpad_txtbox_onoff == n_false ) { return; }


	const  UINT timer_msec = 1;
	static UINT timer_id   = 0;


	switch( msg ) {


	case WM_MOVING :

		if ( n_win_dwm_is_on() ) { break; }

		ShowWindow( n_catpad_txtbox_editor.hwnd, SW_NORMAL );

	break;

	case WM_EXITSIZEMOVE :

		if ( n_win_dwm_is_on() ) { break; }

		ShowWindow( n_catpad_txtbox_editor.hwnd, SW_NORMAL );
		n_win_message_send( n_catpad_txtbox_editor.hwnd, WM_PAINT, 0, 0 );

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, timer_msec );

	break;


	case WM_KILLFOCUS :

		if ( n_win_dwm_is_on() ) { break; }

		ShowWindow( n_catpad_txtbox_editor.hwnd, SW_NORMAL );

	break;

	case WM_SETFOCUS :

		if ( n_win_dwm_is_on() ) { break; }

		ShowWindow( n_catpad_txtbox_editor.hwnd, SW_NORMAL );
		n_win_message_send( n_catpad_txtbox_editor.hwnd, WM_PAINT, 0, 0 );

		// [x] : WinXP : not working
		// [x] : Win9x : hang-up
		//SetForegroundWindow( hwnd );

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, timer_msec );

	break;

	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam == timer_id )
		{
			ShowWindow( n_catpad_txtbox_editor.hwnd, SW_HIDE );

			n_win_timer_exit( hwnd, timer_id );
		}

	break;


	} // switch


	return;
}

void
n_catpad_flashwindow_refresh( void )
{

	if ( n_catpad_txtbox_onoff )
	{
		n_catpad_flashwindow_proc( GetParent( n_catpad_txtbox_editor.hwnd ), WM_SETFOCUS, 0,0 );
	}


	return;
}


