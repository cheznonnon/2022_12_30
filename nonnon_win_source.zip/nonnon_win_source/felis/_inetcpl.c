// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/registry.c"




// internal
void
n_inetcpl_setting_online( void )
{

	HKEY hive = HKEY_CURRENT_USER;

	const n_posix_char *subkey = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" );

	const n_posix_char *lval = n_posix_literal( "GlobalUserOffline" );


	if ( n_false == n_registry_is_exist( hive, subkey, lval ) )
	{
		DWORD zero = 0;
		n_registry_write( hive, subkey, lval, REG_DWORD, &zero, 0 );
	}


	return;
}

#define n_inetcpl_setting_get_literal( a,b,c ) n_inetcpl_setting_get( n_posix_literal( a ), b, c )
#define n_inetcpl_setting_set_literal( a,b,c ) n_inetcpl_setting_set( n_posix_literal( a ), b, c )

#define n_inetcpl_setting_get( a,b,c ) n_inetcpl_setting_getset( a, b, c, n_true  )
#define n_inetcpl_setting_set( a,b,c ) n_inetcpl_setting_getset( a, b, c, n_false )

// internal
void
n_inetcpl_setting_getset( const n_posix_char *lval, DWORD type, void *rval, n_bool is_get )
{

	HKEY hive = HKEY_CURRENT_USER;

	const n_posix_char *subkey = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\3" );

	DWORD byte = sizeof( DWORD );


	if ( n_false == n_registry_is_exist( hive, subkey, lval ) ) { return; }


	if ( is_get )
	{
		n_registry_read ( hive, subkey, lval,       rval, byte );
	} else {
		n_registry_write( hive, subkey, lval, type, rval, byte );
	}


	return;
}

DWORD
n_inetcpl_activex_onoff( void )
{

	// [!] : this will be enabled Flash or so under ExtremeHigh

	DWORD v = 0;

	n_inetcpl_setting_get_literal( "1200", REG_DWORD, &v );

	if ( v == 0 ) { v = 3; } else { v = 0; }

	n_inetcpl_setting_set_literal( "1200", REG_DWORD, &v );


	return v;
}

void
n_inetcpl_extremehigh( void )
{

	// [ Rule ]
	//
	//	behavior is known   : ON/OFF
	//	behavior is unknown : KEEP (no touch)


	const n_posix_char *n_inetcpl_setting_table[] = {

		  n_posix_literal( "1001" ), // IE4   : URLACTION_DOWNLOAD_SIGNED_ACTIVEX
		  n_posix_literal( "1004" ), // IE4   : URLACTION_DOWNLOAD_UNSIGNED_ACTIVEX

		  n_posix_literal( "1200" ), // IE4   : URLACTION_ACTIVEX_RUN
		  n_posix_literal( "1201" ), // IE4   : URLACTION_ACTIVEX_OVERRIDE_OBJECT_SAFETY
	// KEEP	//n_posix_literal( "1204" ), // IE4   : URLACTION_ACTIVEX_CONFIRM_NOOBJECTSAFETY
	// KEEP	//n_posix_literal( "1205" ), // ---   : URLACTION_ACTIVEX_TREATASUNTRUSTED : [MSDN] not implemented
	// KEEP	//n_posix_literal( "1206" ), // IE4   : URLACTION_ACTIVEX_NO_WEBOC_SCRIPT
	// KEEP	//n_posix_literal( "1207" ), // XPSP2 : URLACTION_ACTIVEX_OVERRIDE_REPURPOSEDETECTION : [MSDN] don't touch
		  n_posix_literal( "1208" ), // IE7   : URLACTION_ACTIVEX_OVERRIDE_OPTIN
		  n_posix_literal( "1209" ), // IE7   : URLACTION_ACTIVEX_SCRIPTLET_RUN
		  n_posix_literal( "120A" ), // IE7   : URLACTION_ACTIVEX_DYNSRC_VIDEO_AND_ANIMATION
		  n_posix_literal( "120B" ), // IE8   : URLACTION_ACTIVEX_OVERRIDE_DOMAINLIST

		  n_posix_literal( "1400" ), // IE4   : URLACTION_SCRIPT_RUN
		  n_posix_literal( "1402" ), // IE4   : URLACTION_SCRIPT_JAVA_USE
		  n_posix_literal( "1405" ), // IE4   : URLACTION_SCRIPT_SAFE_ACTIVEX
		  n_posix_literal( "1406" ), // IE4   : URLACTION_CROSS_DOMAIN_DATA
	// ON	//n_posix_literal( "1407" ), // IE5   : URLACTION_SCRIPT_PASTE : [!] : copy/paste/cut/undo/redo feature on/off
		  n_posix_literal( "1408" ), // IE7   : URLACTION_ALLOW_XDOMAIN_SUBFRAME_RESIZE
	// ON	//n_posix_literal( "1409" ), // IE8   : URLACTION_SCRIPT_XSSFILTER : [!] cross-site scripting filter on/off

	// ON	//n_posix_literal( "1601" ), // IE4   : URLACTION_HTML_SUBMIT_FORMS
	// KEEP //n_posix_literal( "1602" ), // IE4   : URLACTION_HTML_SUBMIT_FORMS_FROM
	// KEEP //n_posix_literal( "1603" ), // IE4   : URLACTION_HTML_SUBMIT_FORMS_TO
		  n_posix_literal( "1604" ), // IE4   : URLACTION_HTML_FONT_DOWNLOAD
	// KEEP //n_posix_literal( "1605" ), // IE4   : URLACTION_HTML_JAVA_RUN
		  n_posix_literal( "1606" ), // IE5   : URLACTION_HTML_USERDATA_SAVE
		  n_posix_literal( "1607" ), // IE5   : URLACTION_HTML_SUBFRAME_NAVIGATE
	// ON	//n_posix_literal( "1608" ), // IE6   : URLACTION_HTML_META_REFRESH
		  n_posix_literal( "1609" ), // IE6   : URLACTION_HTML_MIXED_CONTENT
		  n_posix_literal( "160A" ), // IE7   : URLACTION_HTML_INCLUDE_FILE_PATH

		  n_posix_literal( "1800" ), // IE4   : URLACTION_SHELL_INSTALL_DTITEMS
		  n_posix_literal( "1802" ), // IE4   : URLACTION_SHELL_MOVE_OR_COPY
	// KEEP //n_posix_literal( "1803" ), // IE4   : URLACTION_SHELL_FILE_DOWNLOAD
	// KEEP //n_posix_literal( "1804" ), // IE4   : URLACTION_SHELL_VERB
	// KEEP //n_posix_literal( "1805" ), // IE4   : URLACTION_SHELL_WEBVIEW_VERB
	// KEEP //n_posix_literal( "1806" ), // XPSP2 : URLACTION_SHELL_SHELLEXECUTE
	// KEEP //n_posix_literal( "1806" ), // XPSP2 : URLACTION_SHELL_EXECUTE_HIGHRISK
	// KEEP //n_posix_literal( "1807" ), // XPSP2 : URLACTION_SHELL_EXECUTE_MODRISK
	// KEEP //n_posix_literal( "1808" ), // XPSP2 : URLACTION_SHELL_EXECUTE_LOWRISK
	// KEEP //n_posix_literal( "1809" ), // XPSP2 : URLACTION_SHELL_POPUPMGR
	// KEEP //n_posix_literal( "180A" ), // XPSP2 : URLACTION_SHELL_RTF_OBJECTS_LOAD
	// KEEP //n_posix_literal( "180B" ), // XPSP2 : URLACTION_SHELL_ENHANCED_DRAGDROP_SECURITY
	// KEEP //n_posix_literal( "180C" ), // XPSP2 : URLACTION_SHELL_EXTENSIONSECURITY
	// KEEP //n_posix_literal( "180D" ), // XPSP2 : URLACTION_SHELL_SECURE_DRAGSOURCE
	// KEEP //n_posix_literal( "180E" ), // WIN7  : URLACTION_SHELL_REMOTEQUERY
	// KEEP //n_posix_literal( "180F" ), // WIN7  : URLACTION_SHELL_PREVIEW

	// KEEP //n_posix_literal( "1A00" ), // IE4   : URLACTION_CREDENTIALS_USE
	// KEEP //n_posix_literal( "1A01" ), // ---   : URLACTION_AUTHENTICATE_CLIENT : [MSDN] not currently used
	// KEEP //n_posix_literal( "1A02" ), // IE4   : URLACTION_COOKIES
	// KEEP //n_posix_literal( "1A03" ), // IE4   : URLACTION_COOKIES_SESSION
		  n_posix_literal( "1A04" ), // IE6   : URLACTION_CLIENT_CERT_PROMPT
	// KEEP //n_posix_literal( "1A05" ), // IE6   : URLACTION_COOKIES_THIRD_PARTY
	// KEEP //n_posix_literal( "1A06" ), // IE6   : URLACTION_COOKIES_SESSION_THIRD_PARTY
	// KEEP //n_posix_literal( "1A10" ), // IE6   : URLACTION_COOKIES_ENABLED

	// BIN	//n_posix_literal( "1C00" ), // IE4   : URLACTION_JAVA_PERMISSIONS

		//n_posix_literal( "1D00" ), // IE4   : URLACTION_INFODELIVERY_NO_ADDING_CHANNELS
		//n_posix_literal( "1D01" ), // IE4   : URLACTION_INFODELIVERY_NO_EDITING_CHANNELS
		//n_posix_literal( "1D02" ), // IE4   : URLACTION_INFODELIVERY_NO_REMOVING_CHANNELS
		//n_posix_literal( "1D03" ), // IE4   : URLACTION_INFODELIVERY_NO_ADDING_SUBSCRIPTIONS
		//n_posix_literal( "1D04" ), // IE4   : URLACTION_INFODELIVERY_NO_EDITING_SUBSCRIPTIONS
		//n_posix_literal( "1D05" ), // IE4   : URLACTION_INFODELIVERY_NO_REMOVING_SUBSCRIPTIONS
		//n_posix_literal( "1D06" ), // IE4   : URLACTION_INFODELIVERY_NO_CHANNEL_LOGGING

	// BIN	//n_posix_literal( "1E05" ), // IE4   : URLACTION_CHANNEL_SOFTDIST_PERMISSIONS

		  n_posix_literal( "2000" ), // XPSP2 : URLACTION_BEHAVIOR_RUN
		  n_posix_literal( "2001" ), // XPSP2 : URLACTION_MANAGED_SIGNED
		  n_posix_literal( "2004" ), // XPSP2 : URLACTION_MANAGED_UNSIGNED

	// ON	//n_posix_literal( "2100" ), // XPSP2 : URLACTION_FEATURE_MIME_SNIFFING
		  n_posix_literal( "2101" ), // XPSP2 : URLACTION_FEATURE_ZONE_ELEVATION
		  n_posix_literal( "2102" ), // XPSP2 : URLACTION_FEATURE_WINDOW_RESTRICTIONS
		  n_posix_literal( "2103" ), // IE7   : URLACTION_FEATURE_SCRIPT_STATUS_BAR
		  n_posix_literal( "2104" ), // IE7   : URLACTION_FEATURE_FORCE_ADDR_AND_STATUS
		  n_posix_literal( "2105" ), // IE7   : URLACTION_FEATURE_BLOCK_INPUT_PROMPTS
	// KEEP //n_posix_literal( "2106" ), // IE8   : URLACTION_FEATURE_DATA_BINDING

	// ON	//n_posix_literal( "2200" ), // XPSP2 : URLACTION_AUTOMATIC_DOWNLOAD_UI
	// ON	//n_posix_literal( "2201" ), // XPSP2 : URLACTION_AUTOMATIC_ACTIVEX_UI

		  n_posix_literal( "2300" ), //       : URLACTION_ALLOW_RESTRICTEDPROTOCOLS
	// ON	//n_posix_literal( "2301" ), // IE7   : URLACTION_ALLOW_APEVALUATION : [!] phishing filter on/off

		  n_posix_literal( "2400" ), // IE7   : URLACTION_WINDOWS_BROWSER_APPLICATIONS
		  n_posix_literal( "2401" ), // IE7   : URLACTION_XPS_DOCUMENTS
		  n_posix_literal( "2402" ), // IE7   : URLACTION_LOOSE_XAML

	// KEEP //n_posix_literal( "2500" ), // IE7   : URLACTION_LOWRIGHTS : [!] Vista Protected Mode

		  n_posix_literal( "2600" ), // IE7   : URLACTION_WINFX_SETUP

	// ON	//n_posix_literal( "2600" ), // IE7   : URLACTION_INPRIVATE_BLOCKING

		  NULL

	};


	DWORD value = 0;


	// Custom Settings

	n_inetcpl_setting_set_literal( "CurrentLevel", REG_DWORD, &value );


	// Turning ON

	n_inetcpl_setting_set_literal( "1407", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "1409", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "1601", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "1608", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "2100", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "2200", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "2201", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "2301", REG_DWORD, &value );
	n_inetcpl_setting_set_literal( "2600", REG_DWORD, &value );


	// Turning OFF


	// Java

	n_inetcpl_setting_set_literal( "1C00", REG_BINARY, &value );


	// Channel : High

	value = 0x00010000;
	n_inetcpl_setting_set_literal( "1E05", REG_BINARY, &value );



	// OFF

	value = 3;

	int i = 0;
	n_posix_loop
	{

		n_inetcpl_setting_set( n_inetcpl_setting_table[ i ], REG_DWORD, &value );

		i++;
		if ( n_inetcpl_setting_table[ i ] == NULL ) { break; }
	}


	return;
}

