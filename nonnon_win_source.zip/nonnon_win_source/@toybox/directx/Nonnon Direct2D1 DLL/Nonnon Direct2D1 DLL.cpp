// Nonnon Direct2D1
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ How to Install ]
//
//	CAUTION : this takes a lot of time (30min@1.5GHz CPU)
//
//	1 : install "Visual C++ 2008 Express Edition"
//
//		[!] : a bunch of unused features will be installed
//		[!] : you need to install this first, or a bunch of troubles happen
//		[!] : VC2010 makes MSVCR100.DLL dependency
//
//	2 : install "Windows SDK for Windows 7"
//
//		[!] : you can uncheck almost features while installation process
//
//		[7.0]
//			"Developer Tools::Windows Headers and Libraries::Header Files"
//			"Developer Tools::Windows Headers and Libraries::x86 Libraries"
//			"Developer Tools::Windows Development Tools::Win32 Development Tools"
//			"Developer Tools::Visual C++ Compilers"
//
//		[7.1]
//			"Windows Native Code Development::Windows Headers and Libraries::Windows Headers"
//			"Windows Native Code Development::Windows Headers and Libraries::x86 Libraries"
//			"Windows Native Code Development::Tools"
//			"Redistributable Packages::Microsoft Visual C++ 2010"
//
//	3 : set target SDK version to "v7.x"
//
//		[Start Menu]
//			"Microsoft Windows SDK v7.x\Visual Studio Registration\Windows SDK Configuration Tool"
//		[Win8 or later : Path]
//			C:\Program Files\Microsoft SDKs\Windows\v7.1\Setup\WindowsSdkVer.exe
//
//		[Needed] : you need to set this before making a project, otherwise a bunch of troubles happen
//
//
//	[ How to Compile ]
//
//	1 : run Visual Studio IDE
//
//		[Win8 or later : Path]
//		C:\Program Files\Microsoft Visual Studio 9.0\Common7\IDE\VCExpress.exe
//
//	2 : start "New Project"
//
//		"Project types" : "Win32"
//		"Templtates"    : "Win32 Project"
//		"Named"         : "Nonnon Direct2D1 DLL"
//
//	3 : "Win32 Application Wizard"
//
//		buttun          : "Next >"
//		radiobutton     : check "DLL"
//		buttun          : "Finish"
//
//	4 : open "My Documents/Visual Studio 20XX/Projects/Nonnon Direct2D1 DLL"
//
//		copy these files
//
//			"Nonnon Direct2D1 DLL.cpp"
//			"export.def"
//			"rc.rc"
//
//	5 : register "rc.rc"
//
//		drop into "Solution Explorer::Resource Files"
//
//	6 : register "export.def"
//
//		Solution 'Nonnon Direct2D1 DLL'(1 Project)::Nonnon Direct2D1 DLL
//		menu click "Properties"
//		set Configuration "Release"
//		Linker::Input::Module Definition File
//		set "export.def"
//
//	7 : build as "Release"
//
//		[!] : "Nonnon Direct2D1 DLL/Release" has a "Nonnon Direct2D1 DLL.dll"




// [Needed] : for VC Project

#include "stdafx.h"
//#include "Nonnon Direct2D1 DLL.h"

#pragma comment( lib, "D2D1" )

#include <comdef.h>
#include <d2d1.h>




_COM_SMARTPTR_TYPEDEF( ID2D1Bitmap,           __uuidof( ID2D1Bitmap           ) );
_COM_SMARTPTR_TYPEDEF( ID2D1Factory,          __uuidof( ID2D1Factory          ) );
_COM_SMARTPTR_TYPEDEF( ID2D1HwndRenderTarget, __uuidof( ID2D1HwndRenderTarget ) );
_COM_SMARTPTR_TYPEDEF( ID2D1SolidColorBrush,  __uuidof( ID2D1SolidColorBrush  ) );




// [!] : set the same mode with D2D1_RENDER_TARGET_PROPERTIES and D2D1_BITMAP_PROPERTIES
//
//	D2D1_ALPHA_MODE_UNKNOWN       : crash
//	D2D1_ALPHA_MODE_STRAIGHT      : display nothing / reason is unknown
//	D2D1_ALPHA_MODE_PREMULTIPLIED : tearing without Clear()
//	D2D1_ALPHA_MODE_IGNORE        : ok / always run

#define N_D2D1_PIXELFORMAT DXGI_FORMAT_B8G8R8A8_UNORM
#define N_D2D1_ALPHAFORMAT D2D1_ALPHA_MODE_PREMULTIPLIED


static ID2D1Factory           *n_d2d1_ID2D1Factory          = NULL;
static ID2D1HwndRenderTarget  *n_d2d1_ID2D1HwndRenderTarget = NULL;
static ID2D1Bitmap            *n_d2d1_ID2D1Bitmap           = NULL;
static D2D1_BITMAP_PROPERTIES  n_d2d1_D2D1_BITMAP_PROPERTIES;




#define n_d2d1_upsidedown_all( ptr, bmpsx,bmpsy ) n_d2d1_upsidedown( ptr, bmpsx,bmpsy, 0,0,bmpsx,bmpsy )

// internal
BYTE* __stdcall
n_d2d1_upsidedown( BYTE *ptr, int bmpsx, int bmpsy, int x, int y, int sx, int sy )
{

	if ( ptr == NULL ) { return NULL; }


	// [!] : free() a returned variable

/*

	// [x] : this solution is not possible

	// D2D1::Matrix3x2F format
	//
	//	matrix : xX xY
	//	matrix : yX yY
	//	offset in pixels

	n_d2d1_ID2D1HwndRenderTarget->SetTransform
	(
		D2D1::Matrix3x2F
		(
			+1.0, +0.0,
			+0.0, -1.0,
			(FLOAT) 0, (FLOAT) bmpsy
		)
	);
*/

	const int unit   = sizeof( long );
	const int line_f = bmpsx * unit;
	const int line_t =    sx * unit;


	BYTE *ret = (BYTE*) malloc( sx * sy * unit );
//memset( ret, 0xaa, sx * sy * unit );


	int i  = y;
	int ii = 0;
	while( 1 )
	{//break;

		memcpy
		(
			&ret[ ii * line_t ],
			&ptr[ ( x * unit ) + ( ( bmpsy - 1 - i ) * line_f ) ],
			line_t
		);

		i++;
		if ( i >= ( y + sy ) ) { break; }

		ii++;
		if ( ii >= sy ) { break; }
	}


	return ret;
}

// internal
BOOL __stdcall
n_d2d1_rendertarget( HWND hwnd, int sx, int sy )
{

	//if ( ( sx == 0 )||( sy == 0 ) )
	//{
//MessageBox( NULL, TEXT( "1" ), TEXT( "DEBUG" ), 0 );
	//}


	if ( ( sx <= 0 )||( sy <= 0 ) )
	{

		RECT client; GetClientRect( hwnd, &client );

		if ( sx <= 0 ) { sx = client.right;  }
		if ( sy <= 0 ) { sy = client.bottom; }

	}


	//if ( ( sx == 0 )||( sy == 0 ) )
	//{
//MessageBox( NULL, TEXT( "2" ), TEXT( "DEBUG" ), 0 );
	//}


	// [!] : for a minimized window
	//
	//	( ( sx == 0 )||( sy == 0 ) ) is acceptable


	if ( n_d2d1_ID2D1Factory == NULL )
	{
//MessageBox( NULL, TEXT( "n_d2d1_rendertarget()" ), TEXT( "DEBUG" ), 0 );

		if ( n_d2d1_ID2D1HwndRenderTarget != NULL ) { n_d2d1_ID2D1HwndRenderTarget->Release(); }
		n_d2d1_ID2D1HwndRenderTarget = NULL;

		return TRUE;
	}


	if ( n_d2d1_ID2D1HwndRenderTarget == NULL )
	{

		// [MSDN] : faster???

		D2D1_RENDER_TARGET_PROPERTIES targetprop = D2D1::RenderTargetProperties();
		targetprop.pixelFormat = D2D1::PixelFormat
		(
			N_D2D1_PIXELFORMAT,
			N_D2D1_ALPHAFORMAT
		);


		// [!]
		//
		//	D2D1_PRESENT_OPTIONS_IMMEDIATELY : GDI-like rendering == flickering

		n_d2d1_ID2D1Factory->CreateHwndRenderTarget
		(
			targetprop,
			D2D1::HwndRenderTargetProperties
			(
				hwnd,
				D2D1::SizeU( sx, sy ),
				D2D1_PRESENT_OPTIONS_RETAIN_CONTENTS
			),
			&n_d2d1_ID2D1HwndRenderTarget
		);
		if ( n_d2d1_ID2D1HwndRenderTarget == NULL ) { return TRUE; }


		// [Needed] : prevent high-dpi awareness

		FLOAT dpi_x = 96;
		FLOAT dpi_y = 96;

		//n_d2d1_ID2D1HwndRenderTarget->GetDpi( &dpi_x, &dpi_y );
		n_d2d1_ID2D1HwndRenderTarget->SetDpi( dpi_x, dpi_y );


		D2D1_BITMAP_PROPERTIES bmpprop = {
			D2D1::PixelFormat( N_D2D1_PIXELFORMAT, N_D2D1_ALPHAFORMAT ),
			dpi_x, dpi_y
		};
		n_d2d1_D2D1_BITMAP_PROPERTIES = bmpprop;

	} else {

		n_d2d1_ID2D1HwndRenderTarget->Resize
		(
			D2D1::SizeU( sx,sy )
		);

	}


	return FALSE;
}




void __stdcall
n_d2d1_init( void )
{

	HRESULT hr = D2D1CreateFactory( D2D1_FACTORY_TYPE_SINGLE_THREADED, &n_d2d1_ID2D1Factory );
	if ( hr != S_OK )
	{
//MessageBox( NULL, TEXT("D2D1CreateFactory()"), TEXT("DEBUG"), 0 );
	}


	return;
}

void __stdcall
n_d2d1_exit( void )
{

	if ( n_d2d1_ID2D1Factory != NULL )
	{
		n_d2d1_ID2D1Factory->Release();
		n_d2d1_ID2D1Factory = NULL;
	}
	if ( n_d2d1_ID2D1HwndRenderTarget != NULL )
	{
		n_d2d1_ID2D1HwndRenderTarget->Release();
		n_d2d1_ID2D1HwndRenderTarget = NULL;
	}
	if ( n_d2d1_ID2D1Bitmap != NULL )
	{
		n_d2d1_ID2D1Bitmap->Release();
		n_d2d1_ID2D1Bitmap = NULL;
	}


	return;
}

void __stdcall
n_d2d1_bitmap_make( HWND hwnd, void *ptr, int bmpsx, int bmpsy )
{

	// [!] : you can set NULL for "ptr" to make an empty bitmap object


	if ( n_d2d1_rendertarget( hwnd, bmpsx, bmpsy ) ) { return; }


	BOOL upsidedown = FALSE;
	if ( bmpsy > 0 ) { upsidedown = TRUE; } else { bmpsy = abs( bmpsy ); }


	BYTE *ptr_t = (BYTE*) ptr;
	if ( upsidedown ) { ptr_t = n_d2d1_upsidedown_all( (BYTE*) ptr, bmpsx,bmpsy ); }

	{

		n_d2d1_ID2D1HwndRenderTarget->CreateBitmap
		(
			D2D1::SizeU( bmpsx, bmpsy ),
			ptr_t,
			bmpsx * sizeof( long ),
			n_d2d1_D2D1_BITMAP_PROPERTIES,
			&n_d2d1_ID2D1Bitmap
		);

		if ( n_d2d1_ID2D1Bitmap == NULL )
		{
//SetWindowText( hwnd, TEXT("ID2D1HwndRenderTarget->CreateBitmap()") );
		}


	}

	if ( upsidedown ) { free( ptr_t ); }


	return;
}

void __stdcall
n_d2d1_bitmap_copy( HWND hwnd, void *ptr, int bmpsx, int bmpsy, int x, int y )
{

	// [Mechanism]
	//
	//	ptr / bmpsx / bmpsy : bitmap fragment : whole data will be copied
	//	x / y               : destination position on ID2D1Bitmap


	if ( ptr                == NULL ) { return; }
	if ( bmpsx              ==    0 ) { return; }
	if ( bmpsy              ==    0 ) { return; }
	if ( n_d2d1_ID2D1Bitmap == NULL )
	{
//MessageBox( NULL, TEXT( "n_d2d1_ID2D1Bitmap" ), TEXT( "DEBUG" ), 0 );
		return;
	}


	if ( n_d2d1_rendertarget( hwnd, -1, -1 ) ) { return; }


	BOOL upsidedown = FALSE;
	if ( bmpsy > 0 ) { upsidedown = TRUE; } else { bmpsy = abs( bmpsy ); }


	// Clipping

	D2D1_SIZE_U size_u = n_d2d1_ID2D1Bitmap->GetPixelSize();

	int fx  = x;
	int fy  = y;
	int tsx = (int) size_u.width;
	int tsy = (int) size_u.height;
	int tx  = min( tsx, fx + bmpsx );
	int ty  = min( tsy, fy + bmpsy );

	if ( tx > tsx ) { return; }
	if ( ty > tsy ) { return; }


	int   line      = 0;
	int   line_byte = bmpsx * 4;
	BYTE *p         = (BYTE*) ptr;

	if ( upsidedown ) { line = ( bmpsy - 1 ) * line_byte; }

	while( 1 )
	{//break;

		// [Mechanism]
		//
		//	rect_u : position and size on ID2D1Bitmap
		//
		//	CopyFromMemory() uses whole data
		//	data needs to be Top-Down-DIB

		D2D1_RECT_U rect_u = D2D1::RectU( fx, fy, tx, fy + 1 );

		int index = line;
		if ( upsidedown ) { index = bmpsy - 1 - line; }

		n_d2d1_ID2D1Bitmap->CopyFromMemory
		(
			&rect_u,
			&p[ line ],
			line_byte
		);

		if ( upsidedown ) { line -= line_byte; } else { line += line_byte; }


		fy++;
		if ( fy >= ty ) { break; }
	}


	return;
}

void __stdcall
n_d2d1_bitmap_draw( HWND hwnd, int x, int y, int sx, int sy )
{

	// [Mechanism]
	//
	//	draw ID2D1Bitmap data to a window
	//
	//	x y sx sy : use for narrowing the drawing area


	if ( n_d2d1_rendertarget( hwnd, -1, -1 ) ) { return; }


	n_d2d1_ID2D1HwndRenderTarget->BeginDraw();


	// [Needed] : tearing will occur without this

	if ( N_D2D1_ALPHAFORMAT == D2D1_ALPHA_MODE_PREMULTIPLIED )
	{
		n_d2d1_ID2D1HwndRenderTarget->Clear( NULL );
	}


	{

		D2D1_SIZE_U size_u = n_d2d1_ID2D1Bitmap->GetPixelSize();

		int f_fx = x;
		int f_fy = y;
		int f_tx = x + min( sx, (int) size_u.width  );
		int f_ty = y + min( sy, (int) size_u.height );
		int t_fx = f_fx;
		int t_fy = f_fy;
		int t_tx = f_tx;
		int t_ty = f_ty;


		D2D1_RECT_F rc_f = { (FLOAT) f_fx, (FLOAT) f_fy, (FLOAT) f_tx, (FLOAT) f_ty };
		D2D1_RECT_F rc_t = { (FLOAT) t_fx, (FLOAT) t_fy, (FLOAT) t_tx, (FLOAT) t_ty };

		n_d2d1_ID2D1HwndRenderTarget->DrawBitmap
		(
			n_d2d1_ID2D1Bitmap,
			rc_t,
			1.0,
			D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR,
			rc_f
		);

	}

	n_d2d1_ID2D1HwndRenderTarget->EndDraw();


	return;
}



/*
void __stdcall
n_d2d1_rectangle( HWND hwnd, int x, int y, int sx, int sy, COLORREF color )
{

	// [x] : currently buggy

	n_d2d1_ID2D1HwndRenderTarget->BeginDraw();

	{

		ID2D1SolidColorBrush *brush;
		FLOAT                 u = 1.0F / 255.0F;
		FLOAT                 r = u * (FLOAT) GetRValue( color );
		FLOAT                 g = u * (FLOAT) GetGValue( color );
		FLOAT                 b = u * (FLOAT) GetBValue( color );

		n_d2d1_ID2D1HwndRenderTarget->CreateSolidColorBrush( D2D1::ColorF( r, g, b, 1.0 ), &brush );//D2D1::ColorF::Blue;
		n_d2d1_ID2D1HwndRenderTarget->FillRectangle( D2D1::RectF( (FLOAT) x, (FLOAT) y, (FLOAT) sx, (FLOAT) sy ), brush );

	}

	n_d2d1_ID2D1HwndRenderTarget->EndDraw();


	return;
}

void __stdcall
n_d2d1_bitmap_partialcopy( HWND hwnd, void *ptr, int bmpsx, int bmpsy, int fx, int fy, int fsx, int fsy, int tx, int ty )
{

	// [x] : this approach is heavy

	// [Mechanism] : use n_bmp_new() and n_bmp_fastcopy() to cut a bitmap fragment


	if ( ptr                == NULL ) { return; }
	if ( bmpsx              ==    0 ) { return; }
	if ( bmpsy              ==    0 ) { return; }
	if ( n_d2d1_ID2D1Bitmap == NULL ) { return; }


	if ( n_d2d1_rendertarget( hwnd, -1, -1 ) ) { return; }


	BOOL upsidedown = FALSE;
	if ( bmpsy > 0 ) { upsidedown = TRUE; } else { bmpsy = abs( bmpsy ); }


	// Phase 1 : make a source bitmap

	ID2D1Bitmap *ID2D1Bitmap = NULL;

	BYTE *ptr_t = (BYTE*) ptr;
	if ( upsidedown ) { ptr_t = n_d2d1_upsidedown_all( (BYTE*) ptr, bmpsx,bmpsy ); }

	n_d2d1_ID2D1HwndRenderTarget->CreateBitmap
	(
		D2D1::SizeU( bmpsx, bmpsy ),
		ptr_t,
		bmpsx * sizeof( long ),
		n_d2d1_D2D1_BITMAP_PROPERTIES,
		&ID2D1Bitmap
	);

	if ( upsidedown ) { free( ptr_t ); }


	if ( ID2D1Bitmap == NULL )
	{
//SetWindowText( hwnd, TEXT( "n_d2d1_bitmap_copy()" ) );
		return;
	}


	// Phase 2 : copy to main bitmap 

	if ( fx < 0 ) { fsx += fx; fx = abs( fx ); }
	if ( fy < 0 ) { fsy += fy; fy = abs( fy ); }

	if ( tx < 0 ) { fsx += tx; fx = abs( tx ); tx = 0; }
	if ( ty < 0 ) { fsy += ty; fy = abs( ty ); ty = 0; }

	D2D1_RECT_U   from = D2D1::RectU( fx,fy,fx+fsx,fy+fsy );
	D2D1_POINT_2U to   = D2D1::Point2U( tx, ty );

	n_d2d1_ID2D1Bitmap->CopyFromBitmap
	(
		&to,
		ID2D1Bitmap,
		&from
	);


	return;
}
*/


