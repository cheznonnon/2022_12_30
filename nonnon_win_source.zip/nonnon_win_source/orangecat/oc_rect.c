// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	n_type_real x,y,sx,sy;

} n_oc_rect;




#define n_oc_rect_reset( p ) n_oc_rect_set( p, -3,-3,-3,-3 )

void
n_oc_rect_set( n_oc_rect *p, n_type_real x, n_type_real y, n_type_real sx, n_type_real sy )
{

	p->x  = x;
	p->y  = y;
	p->sx = sx;
	p->sy = sy;


	return;
}

n_bool
n_oc_rect_is_hovered( n_oc_rect *p, HWND hwnd )
{

	n_type_gfx  x = (n_type_gfx) p->x;
	n_type_gfx  y = (n_type_gfx) p->y;
	n_type_gfx sx = (n_type_gfx) p->sx;
	n_type_gfx sy = (n_type_gfx) p->sy;

	return n_win_is_hovered_offset( hwnd, x,y,sx,sy );
}

