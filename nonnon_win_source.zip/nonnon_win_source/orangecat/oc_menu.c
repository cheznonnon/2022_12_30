// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_menu_arrange( void )
{

	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_LOGO, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_ICON, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_PATH, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_DATE, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_SIZE, ' ' );

	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_LOGO, 'O' );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_ICON, 'O' );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_PATH )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_PATH, 'O' );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_DATE )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_DATE, 'O' );
	} else
	if ( oc.view_type == N_ORANGECAT_VIEW_TYPE_SIZE )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_VIEW_SIZE, 'O' );
	}


	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_16 , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_24 , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_32 , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_48 , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_64 , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_256, ' ' );

	if ( oc.unit_rsrc ==  16 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_16 , 'O' );
	} else
	if ( oc.unit_rsrc ==  24 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_24 , 'O' );
	} else
	if ( oc.unit_rsrc ==  32 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_32 , 'O' );
	} else
	if ( oc.unit_rsrc ==  48 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_48 , 'O' );
	} else
	if ( oc.unit_rsrc ==  64 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_64 , 'O' );
	} else
	if ( oc.unit_rsrc == 256 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_ICON_256, 'O' );
	}


	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP_04, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP_08, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP_32, ' ' );

	if ( oc.unit__bpp ==  4 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP_04, 'O' );
	} else
	if ( oc.unit__bpp ==  8 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP_08, 'O' );
	} else
	if ( oc.unit__bpp == 32 )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_BPP_32, 'O' );
	}


	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_AUTO    , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_CLASSIC , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_LUNA    , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_AERO    , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_8       , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_FLUENT  , ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_MATERIAL, ' ' );
	n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_AQUA    , ' ' );

	if ( oc.style_auto )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_AUTO    , 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_CLASSIC )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_CLASSIC , 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_LUNA    )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_LUNA    , 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_AERO    )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_AERO    , 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_8       )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_8       , 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_FLUENT  )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_FLUENT  , 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_MATERIAL )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_MATERIAL, 'O' );
	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA    )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_STYLE_AQUA    , 'O' );
	}// else


	if ( oc.view_is_computer )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_TOOL_FOLDER, 'x' );
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_TOOL_CMD   , 'x' );
	} else {
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_TOOL_FOLDER, ' ' );
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_TOOL_CMD   , ' ' );
	}


	if ( oc.view_is_computer )
	{
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_OUTPUT_FIND_1, 'x' );
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_OUTPUT_FIND_2, 'x' );
	} else {
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_OUTPUT_FIND_1, ' ' );
		n_win_simplemenu_tweak_literal( &oc.menu, N_ORANGECAT_MENU_OUTPUT_FIND_2, ' ' );
	}


	return;
}

void
n_oc_menu_init( void )
{

	n_win_simplemenu_zero( &oc.menu );
	n_win_simplemenu_init( &oc.menu );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_BACK          , NULL, n_posix_literal( "[ ]Back"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_HOME          , NULL, n_posix_literal( "[ ]Home"    ), NULL );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_VIEW          , NULL, n_posix_literal( "[h]View"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_VIEW_LOGO     , NULL, n_posix_literal( "[ ]Logo"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_VIEW_ICON     , NULL, n_posix_literal( "[ ]Icon"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_VIEW_PATH     , NULL, n_posix_literal( "[ ]Path"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_VIEW_DATE     , NULL, n_posix_literal( "[ ]Date"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_VIEW_SIZE     , NULL, n_posix_literal( "[ ]Size"    ), NULL );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON          , NULL, n_posix_literal( "[h]Icon"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON_16       , NULL, n_posix_literal( "[ ]16"      ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON_24       , NULL, n_posix_literal( "[ ]24"      ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON_32       , NULL, n_posix_literal( "[ ]32"      ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON_48       , NULL, n_posix_literal( "[ ]48"      ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON_64       , NULL, n_posix_literal( "[ ]64"      ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_ICON_256      , NULL, n_posix_literal( "[ ]256"     ), NULL );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_BPP           , NULL, n_posix_literal( "[h]Colors"     ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_BPP_04        , NULL, n_posix_literal( "[ ]16"         ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_BPP_08        , NULL, n_posix_literal( "[ ]256"        ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_BPP_32        , NULL, n_posix_literal( "[ ]Full Color" ), NULL );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE         , NULL, n_posix_literal( "[h]Style"    ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_AUTO    , NULL, n_posix_literal( "[ ]Auto"     ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_CLASSIC , NULL, n_posix_literal( "[ ]Classic"  ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_LUNA    , NULL, n_posix_literal( "[ ]Luna"     ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_AERO    , NULL, n_posix_literal( "[ ]Aero"     ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_8       , NULL, n_posix_literal( "[ ]8"        ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_FLUENT  , NULL, n_posix_literal( "[ ]Fluent"   ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_MATERIAL, NULL, n_posix_literal( "[ ]Material" ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_STYLE_AQUA    , NULL, n_posix_literal( "[ ]Aqua"     ), NULL );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_TOOL          , NULL, n_posix_literal( "[H]Tool"           ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_TOOL_FOLDER   , NULL, n_posix_literal( "[ ]New Folder"     ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_TOOL_CMD      , NULL, n_posix_literal( "[ ]Command Prompt" ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_TOOL_PROPERTY , NULL, n_posix_literal( "[ ]Property"       ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_TOOL_EXPLORER , NULL, n_posix_literal( "[ ]Explorer"       ), NULL );

	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_LINE          , NULL, n_posix_literal( "[-]"                           ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_OUTPUT_FIND_1 , NULL, n_posix_literal( "[ ]Output \"Name Search.lnk\"" ), NULL );
	n_win_simplemenu_set( &oc.menu, N_ORANGECAT_MENU_OUTPUT_FIND_2 , NULL, n_posix_literal( "[ ]Output \"Text Search.lnk\"" ), NULL );

	n_oc_menu_arrange();


	game.simplemenu = &oc.menu;


	n_win_titlemenu_init_main( &oc.titlemenu, game.hwnd, &oc.menu );


	return;
}

void
n_oc_menu_exit( void )
{

	n_win_titlemenu_exit( &oc.titlemenu );

	n_win_simplemenu_exit( &oc.menu );


	return;
}

n_bool
n_oc_menu_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( msg != WM_COMMAND ) { return n_false; }

//n_game_hwndprintf_literal( " %x %x %x ", lparam, oc.menu.hwnd, oc.titlemenu.hwnd_menu );
//n_game_hwndprintf_literal( " %x %x %x ", lparam, oc.menu.hwnd, oc.titlemenu.smenu->hwnd );

	if ( (HWND) lparam != oc.menu.hwnd ) { return n_false; }


	if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
	{
		n_oc_menu_arrange();
	} else
	if ( wparam == N_ORANGECAT_MENU_BACK )
	{
		n_oc_navigate_back();
	} else
	if ( wparam == N_ORANGECAT_MENU_HOME )
	{
		n_oc_navigate( oc.home );
	} else
	if (
		( wparam >= N_ORANGECAT_MENU_VIEW_LOGO )
		&&
		( wparam <= N_ORANGECAT_MENU_VIEW_SIZE )
	)
	{

		int p_view_type = oc.view_type;

		if ( wparam == N_ORANGECAT_MENU_VIEW_LOGO ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_LOGO; } else
		if ( wparam == N_ORANGECAT_MENU_VIEW_ICON ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_ICON; } else
		if ( wparam == N_ORANGECAT_MENU_VIEW_PATH ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_PATH; } else
		if ( wparam == N_ORANGECAT_MENU_VIEW_DATE ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_DATE; } else
		if ( wparam == N_ORANGECAT_MENU_VIEW_SIZE ) { oc.view_type = N_ORANGECAT_VIEW_TYPE_SIZE; }// else

		if ( p_view_type != oc.view_type )
		{
			oc.transition_is_first = n_posix_true;

			if ( oc.transition_onoff )
			{
//n_posix_debug_literal( "1" );
				oc.view_is_changed = n_true;
			} else {
//n_posix_debug_literal( "2" );
				n_oc_item_view_change( &item );
			}

			n_oc_event_redraw();
		}

		return n_posix_true;

	} else
	if (
		( wparam >= N_ORANGECAT_MENU_ICON_16  )
		&&
		( wparam <= N_ORANGECAT_MENU_ICON_256 )
	)
	{

		int prev = oc.unit_rsrc;

		if ( wparam == N_ORANGECAT_MENU_ICON_16   ) { oc.unit_rsrc =  16; } else
		if ( wparam == N_ORANGECAT_MENU_ICON_24   ) { oc.unit_rsrc =  24; } else
		if ( wparam == N_ORANGECAT_MENU_ICON_32   ) { oc.unit_rsrc =  32; } else
		if ( wparam == N_ORANGECAT_MENU_ICON_48   ) { oc.unit_rsrc =  48; } else
		if ( wparam == N_ORANGECAT_MENU_ICON_64   ) { oc.unit_rsrc =  64; } else
		if ( wparam == N_ORANGECAT_MENU_ICON_256  ) { oc.unit_rsrc = 256; }

		if ( prev != oc.unit_rsrc )
		{
			oc.transition_is_first = n_posix_true;

			n_oc_item_view_change( &item );
			n_oc_event_redraw();
		}

		return n_posix_true;

	} else
	if (
		( wparam >= N_ORANGECAT_MENU_BPP_04 )
		&&
		( wparam <= N_ORANGECAT_MENU_BPP_32 )
	)
	{

		int prev = oc.unit__bpp;

		if ( wparam == N_ORANGECAT_MENU_BPP_04 ) { oc.unit__bpp =  4; } else
		if ( wparam == N_ORANGECAT_MENU_BPP_08 ) { oc.unit__bpp =  8; } else
		if ( wparam == N_ORANGECAT_MENU_BPP_32 ) { oc.unit__bpp = 32; }

		if ( prev != oc.unit__bpp )
		{
			oc.transition_is_first = n_posix_true;

			n_oc_item_view_change( &item );
			n_oc_event_redraw();
		}

		return n_posix_true;

	} else
	if (
		( wparam >= N_ORANGECAT_MENU_STYLE_AUTO )
		&&
		( wparam <= N_ORANGECAT_MENU_STYLE_AQUA )
	)
	{

		int p_style = oc.style;

		oc.style_auto = n_false;

		if ( wparam == N_ORANGECAT_MENU_STYLE_AUTO     ) { oc.style_auto = n_true; p_style = oc.style + 1; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_CLASSIC  ) { oc.style = N_ORANGECAT_STYLE_CLASSIC ; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_LUNA     ) { oc.style = N_ORANGECAT_STYLE_LUNA    ; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_AERO     ) { oc.style = N_ORANGECAT_STYLE_AERO    ; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_8        ) { oc.style = N_ORANGECAT_STYLE_8       ; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_FLUENT   ) { oc.style = N_ORANGECAT_STYLE_FLUENT  ; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_MATERIAL ) { oc.style = N_ORANGECAT_STYLE_MATERIAL; } else
		if ( wparam == N_ORANGECAT_MENU_STYLE_AQUA     ) { oc.style = N_ORANGECAT_STYLE_AQUA    ; }// else

		if ( p_style != oc.style )
		{
			oc.transition_is_first = n_posix_true;

			n_oc_reset_style();
		}

		return n_posix_true;

	} else
	if ( wparam == N_ORANGECAT_MENU_TOOL_FOLDER )
	{

		if ( oc.view_is_computer )
		{

			//

		} else {

			n_posix_char *temp = n_string_path_tmpname_new( N_STRING_EMPTY );
			n_posix_char *name = n_string_path_make_new( oc.main, temp );

			n_posix_mkdir( name );

			n_oc_item_multifocus_path2focus_light( &item, temp, n_true, n_true );
			n_oc_event_redraw_fast();

			n_string_path_free( temp );
			n_string_path_free( name );

		}

	} else
	if ( wparam == N_ORANGECAT_MENU_TOOL_CMD )
	{

		if ( n_sysinfo_version_9x() )
		{
			n_win_exec_literal( "command.com", SW_NORMAL );
		} else {
			n_win_exec_literal( "cmd.exe",     SW_NORMAL );
		}

	} else
	if ( wparam == N_ORANGECAT_MENU_TOOL_PROPERTY )
	{

		n_type_int count = n_oc_item_multifocus_count( &item );

		if ( count == 0 )
		{

			if ( oc.view_is_computer )
			{

				// [!] : call "System Properties"

				n_explorer_property( NULL );

			} else {

				n_explorer_property( oc.main );

			}

		} else
		if ( count == 1 )
		{

			n_type_int    index = n_oc_item_multifocus_single( &item );
			n_posix_char *str   = n_oc_item_index2path_new( &item, index );

			n_explorer_property( str );

			n_string_path_free( str );

		}

	} else
	if ( wparam == N_ORANGECAT_MENU_TOOL_EXPLORER )
	{

		// [Needed] : WinVista

		n_win_simplemenu_hide( &oc.menu );

		if ( oc.view_is_computer )
		{

			// [!] : Compatibility : 95 or later

			// [!] : call "My Computer"

			n_explorer_open( NULL, SW_NORMAL );

		} else {

			n_type_int count = n_oc_item_multifocus_count( &item );

			if ( count == 0 )
			{

				n_explorer_open( N_STRING_DOT, SW_NORMAL );

			} else
			if ( count == 1 )
			{

				n_type_int    index = n_oc_item_multifocus_single( &item );
				n_posix_char *str   = n_oc_item_index2path_new( &item, index );

				n_explorer_open( str, SW_NORMAL );

				n_string_path_free( str );

			} else {

				n_type_int i = 0;
				n_posix_loop
				{

					if ( item.multifocus[ i ] )
					{
						n_posix_char *name = n_oc_item_index2path_new( &item, i );

						n_explorer_open( name, SW_NORMAL );

						n_string_path_free( name );
					}


					i++;
					if ( i >= item.count ) { break; }
				}

			}

		}

	} else
	if ( wparam == N_ORANGECAT_MENU_OUTPUT_FIND_1 )
	{

		n_posix_char *lnk = n_string_path_make_new( oc.main, n_posix_literal( "OrangeCat Name Search" ) );

#ifdef NONNON_APPS
		n_posix_char *opt = n_string_path_cat( N_APPS_OPTION_ORANGECAT, N_STRING_SPACE, N_ORANGECAT_OPTION_FIND_NAME, NULL );
#else  // #ifdef NONNON_APPS
		n_posix_char *opt = n_string_path_cat(                                          N_ORANGECAT_OPTION_FIND_NAME, NULL );
#endif // #ifdef NONNON_APPS


		n_IShellLink_path2lnk( lnk, oc.exec, opt, oc.exec, N_APPS_ICON_OFFSET_ORANGECAT );

		n_string_path_free( lnk );
		n_string_path_free( opt );


		const n_posix_char *nam = n_posix_literal( "OrangeCat Name Search.lnk\0\0" );

		n_oc_item_sync_go( &item );
		n_oc_item_multifocus_off_all( &item );
		n_oc_item_multifocus_path2focus_light( &item, nam, n_false, n_true );
		n_oc_event_redraw_fast();

	} else
	if ( wparam == N_ORANGECAT_MENU_OUTPUT_FIND_2 )
	{

		n_posix_char *lnk = n_string_path_make_new( oc.main, n_posix_literal( "OrangeCat Text Search" ) );

#ifdef NONNON_APPS
		n_posix_char *opt = n_string_path_cat( N_APPS_OPTION_ORANGECAT, N_STRING_SPACE, N_ORANGECAT_OPTION_FIND_TEXT, NULL );
#else  // #ifdef NONNON_APPS
		n_posix_char *opt = n_string_path_cat(                                          N_ORANGECAT_OPTION_FIND_TEXT, NULL );
#endif // #ifdef NONNON_APPS


		n_IShellLink_path2lnk( lnk, oc.exec, opt, oc.exec, N_APPS_ICON_OFFSET_ORANGECAT );

		n_string_path_free( lnk );
		n_string_path_free( opt );


		const n_posix_char *nam = n_posix_literal( "OrangeCat Text Search.lnk\0\0" );

		n_oc_item_sync_go( &item );
		n_oc_item_multifocus_off_all( &item );
		n_oc_item_multifocus_path2focus_light( &item, nam, n_false, n_true );
		n_oc_event_redraw_fast();

	}// else


	return n_false;
}


