// Nonnon White Noise
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




#include "../nonnon/game/sound/directsound.c"
#include "../nonnon/game/sound/waveout.c"
#include "../nonnon/game/timegettime.c"

#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_simplemenu.c"
#include "../nonnon/win32/win_systray.c"

#include "../nonnon/project/macro.c"




#ifndef NONNON_APPS

#define N_APPS_OPTION_WHITENOISE n_posix_literal( "-whitenoise" )

#define N_APPS_ICON_OFFSET_WHITENOISE ( 0 )

#endif // #ifndef NONNON_APPS




#define N_WHITENOISE_APPNAME n_posix_literal( "Nonnon White Noise" )




#define N_WHITENOISE_TIMER_INTERVAL 5000



static UINT n_whitenoise_timer_id = 0;
static UINT n_whitenoise_tray_id  = 0;




n_type_real
n_wav_sample_sandstorm_binaural( n_type_real hz, u32 x, u32 offset )
{

	// [!] : human recognition
	//
	//	20Hz to 20,000Hz


	n_type_real f = n_posix_minmax_n_type_real( 1, 44100, 1 + n_random_range( (u32) hz ) );
	if ( f < ( 44100 - offset ) ) { f += offset; }

	n_type_real d = n_wav_sample_sine( f, x );


	return d;
}

void
n_wav_sandstorm_binaural( n_wav *wav, n_type_real hz, n_type_real ratio_l, n_type_real ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	const u32 count = N_WAV_COUNT( wav );


	n_random_shuffle();


	u32 x = 0;
	n_posix_loop
	{

		// [!] : brain waves
		//
		//	theta : 4 Hz -  7 Hz
		//	alpha : 8 Hz - 15 Hz

		u32 o = 6;//4 + n_random_range( 12 );

		n_type_real d_l = n_wav_sample_sandstorm_binaural( hz, x, 0 );
		n_type_real d_r = n_wav_sample_sandstorm_binaural( hz, x, o );

		n_wav_sample_mix( wav, x, d_l, d_r, ratio_l, ratio_r );


		x++;
		if ( x >= count ) { break; }
	}


	return;
}

n_posix_char*
n_whitenoise_startup_commandline( void )
{

	n_posix_char *exe = n_win_exepath_new();

#ifdef NONNON_APPS

	n_posix_char *ret = n_string_path_cat( exe, N_STRING_SPACE, N_APPS_OPTION_WHITENOISE, NULL );
	n_string_free( exe );

#else  // #ifndef NONNON_APPS

	n_posix_char *ret = exe;

#endif // #ifndef NONNON_APPS


	return ret;
}

// internal
void
n_whitenoise_relaunch( HWND hwnd )
{

	n_posix_char *exe = n_whitenoise_startup_commandline();

	n_win_exec( exe, SW_NORMAL );

	n_string_path_free( exe );

	n_win_message_send( hwnd, WM_CLOSE, 0, 0 );


	return;
}

void
n_whitenoise_systray_init( NOTIFYICONDATA *nid, HWND hwnd_parent, n_bool redraw )
{

	n_posix_char *exe = n_win_exepath_new();

	n_win_systray_init
	(
		nid,
		hwnd_parent,
		n_whitenoise_tray_id,
		exe,
		N_WHITENOISE_APPNAME,
		redraw
	);

	int icon_supported[] = { 16, 32, 48, 0 };

	n_win_systray_icon_change( nid, exe, N_APPS_ICON_OFFSET_WHITENOISE, icon_supported );

	n_string_path_free( exe );


	return;
}

LRESULT CALLBACK
n_whitenoise_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static NOTIFYICONDATA   nid;
	static n_directsound    directsound;
	static n_waveout        waveout;
	static n_wav            wav;
	static n_win_simplemenu menu;
	static n_bool           is_directsound;
	static UINT             msg_explorer_crashed = WM_NULL;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		// [Patch] : old version of n_win_systray_icon_change()
		//
		//	GetDIBits() will fail

		//if ( ( n_sysinfo_version_9x() )&&( wparam == SPI_SETNONCLIENTMETRICS ) )
		//{
		//	n_whitenoise_relaunch( hwnd );
		//} else {
			n_whitenoise_systray_init( &nid, hwnd, n_true );
		//}

	break;


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();

		n_game_timegettime_init();

		n_win_ime_disable( hwnd );

		msg_explorer_crashed = RegisterWindowMessage( n_posix_literal( "TaskbarCreated" ) );


		n_project_darkmode();

		n_whitenoise_tray_id = N_PROJECT_SYSTRAY_ID_WHITENOISE;


		// Window

		n_win_init( hwnd, N_WHITENOISE_APPNAME, N_STRING_EMPTY, N_STRING_EMPTY );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		n_win_simplemenu_zero( &menu );
		n_win_simplemenu_init( &menu );

		n_win_simplemenu_set( &menu, 0, NULL, n_posix_literal( "[ ]Register"   ), NULL );
		n_win_simplemenu_set( &menu, 1, NULL, n_posix_literal( "[ ]Unregister" ), NULL );
		n_win_simplemenu_set( &menu, 2, NULL, n_posix_literal( "[-]"           ), NULL );
		n_win_simplemenu_set( &menu, 3, NULL, n_posix_literal( "[ ]Exit"       ), NULL );


		// Display

		ShowWindow( hwnd, SW_HIDE );
		//ShowWindow( hwnd, SW_NORMAL );


		// White Noise

		{

			const n_type_real output = 0.10;

			n_wav_zero( &wav );
			n_wav_new( &wav, N_WHITENOISE_TIMER_INTERVAL * 2 );
			n_wav_sandstorm_binaural( &wav, 44100, output, output );

			n_directsound_zero( &directsound );
			n_bool ret = n_directsound_init( &directsound, hwnd, &wav );

			if ( ret )
			{
				n_waveout_zero( &waveout );
				ret = n_waveout_init( &waveout, &wav );

				is_directsound = n_false;
			} else {
				is_directsound = n_true;
			}

			if ( ret ) { n_wav_free( &wav ); return -1; }

			if ( is_directsound )
			{
				n_directsound_loop( &directsound );
			} else {
				n_waveout_loop( &waveout );
			}

		}


		// Init

		n_whitenoise_systray_init( &nid, hwnd, n_true );

		if ( n_whitenoise_timer_id == 0 ) { n_whitenoise_timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, n_whitenoise_timer_id, N_WHITENOISE_TIMER_INTERVAL );

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != nid.uID ) { break; }

		if ( lparam == WM_RBUTTONUP )
		{
			if ( n_win_is_input( VK_CONTROL ) )
			{
				// [Needed] : to disappear a popup menu
				SetForegroundWindow( hwnd );
				n_win_simplemenu_show( &menu, hwnd );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}
		}

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != n_whitenoise_timer_id ) { break; }

		if ( is_directsound )
		{
			n_directsound_loop( &directsound );
		} else {
			n_waveout_loop( &waveout );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == menu.hwnd )
		{
			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				//
			} else
			if ( wparam == 0 )
			{

				// [x] : Win95 : not supported
				//ShellExecute( hwnd, NULL, n_posix_literal( "shell:startup" ), NULL, NULL, SW_SHOWNORMAL );

				n_posix_char *rval = n_whitenoise_startup_commandline();

				n_project_startup_register( N_WHITENOISE_APPNAME, rval );

				n_string_free( rval );

			} else
			if ( wparam == 1 )
			{

				n_project_startup_unregister( N_WHITENOISE_APPNAME );

			} else
			if ( wparam == 2 )
			{

				// [!] : Separator

			} else
			if ( wparam == 3 )
			{

				n_win_message_send( hwnd, WM_CLOSE, 0,0 );

			}// else
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_win_timer_exit( hwnd, n_whitenoise_timer_id );


		if ( is_directsound )
		{

			n_directsound_exit( &directsound );

		} else {

			// [!] : n_waveout_exit() uses WAVEHDR

			n_waveout_exit( &waveout );

		}

		n_wav_free( &wav );


		n_win_systray_exit( &nid );

		n_win_simplemenu_exit( &menu );

		n_game_timegettime_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	if ( msg == msg_explorer_crashed )
	{
		n_win_systray_exit( &nid );
		n_whitenoise_systray_init( &nid, hwnd, n_true );
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, &menu );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_whitenoise_wndproc );
}

#endif // #ifndef NONNON_APPS


