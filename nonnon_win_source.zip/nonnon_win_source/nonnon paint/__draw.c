// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/bmp.c"
#include "../nonnon/neutral/bmp/all.c"




void
n_bmp_thicken( n_bmp *bmp )
{

	const n_type_real ratio = 1.5;


	n_bmp_flush_antialias( bmp, 1.0 );


	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a = n_bmp_a( color );
		if ( a != 0 )
		{
			u32 c = n_bmp_blend_pixel( n_bmp_white_invisible, n_bmp_black, (n_type_real) a * ratio * n_bmp_coeff_channel );
			n_bmp_ptr_set_fast( bmp, x,y, c );
		}


		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

void
n_bmp_thin( n_bmp *bmp )
{

	n_bmp_flush_antialias( bmp, 1.0 );

	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a = n_bmp_a( color );
		if ( ( a != 0 )&&( a != 255 ) )
		{
			if ( a < 128 )
			{
				n_bmp_ptr_set_fast( bmp, x,y, n_bmp_white_invisible );
			}
		}


		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}

	n_bmp_flush_antialias( bmp, 1.0 );


	return;
}

void
n_bmp_contour( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a = n_bmp_a( color );
		//int r = n_bmp_r( color );
		//int g = n_bmp_g( color );
		//int b = n_bmp_b( color );

		if ( a != 0 )
		{
			color = n_bmp_black;
			n_bmp_ptr_set_fast( bmp, x,y, color );
		}

		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{
			x = 0;
			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}


	const n_type_gfx contour = 1;
	const n_type_gfx modify  = ( 0 == ( contour % 1 ) );

	n_bmp bmp_old; n_bmp_zero( &bmp_old ); n_bmp_carboncopy( bmp, &bmp_old );

	x = -contour;
	y = -contour;
	n_posix_loop
	{

		n_bmp_transcopy( &bmp_old, bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), x,y );

		x++;
		if ( x >= ( contour + modify ) )
		{
			x = -contour;
			y++;
			if ( y >= ( contour + modify ) ) { break; }
		}
	}

	n_bmp_free( &bmp_old );


	return;
}

void
n_bmp_line_reverse( n_bmp *bmp, n_bmp *bmp_onoff, n_type_gfx fx, n_type_gfx fy, n_type_gfx tx, n_type_gfx ty )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_real step = 0;
	n_type_real unit = (n_type_real) abs( fy - ty ) / n_posix_max_n_type_gfx( 1, abs( fx - tx ) );


	n_posix_loop
	{

		// [!] : need to draw the first pos

		u32 onoff;
		n_bmp_ptr_get( bmp_onoff, fx,fy, &onoff );
		if ( onoff == 0 )
		{

			n_bmp_ptr_set( bmp_onoff, fx,fy, 1 );


			u32 color;
			n_bmp_ptr_get( bmp, fx,fy, &color );

			int a = 255 - n_bmp_a( color );
			int r = 255 - n_bmp_r( color );
			int g = 255 - n_bmp_g( color );
			int b = 255 - n_bmp_b( color );

			color = n_bmp_argb( a,r,g,b );

			n_bmp_ptr_set( bmp, fx,fy, color );

		}


		// [!] : need to draw tx,ty once or more

		if ( ( fx == tx )&&( fy == ty ) ) { break; }


		// [!] : don't use "else" : avoid zig-zag

		if ( step < 1 )
		{
			step += unit;
			if ( fx > tx ) { fx--; } else if ( fx < tx ) { fx++; }
		}

		if ( step >= 1 )
		{
			step -= 1;
			if ( fy > ty ) { fy--; } else if ( fy < ty ) { fy++; }
		}

	}


	return;
}

void
n_bmp_frame_reverse( n_bmp *bmp, n_bmp *bmp_onoff, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx fx = x;
	n_type_gfx fy = y;
	n_type_gfx tx = x + sx - 1;
	n_type_gfx ty = y + sy - 1;


	// Top
	n_bmp_line_reverse( bmp, bmp_onoff, fx,fy-0,tx,fy-0 );
	n_bmp_line_reverse( bmp, bmp_onoff, fx,fy-1,tx,fy-1 );

	// Bottom
	n_bmp_line_reverse( bmp, bmp_onoff, fx,ty+0,tx,ty+0 );
	n_bmp_line_reverse( bmp, bmp_onoff, fx,ty+1,tx,ty+1 );


	fy++;
	ty--;

	// Left
	n_bmp_line_reverse( bmp, bmp_onoff, fx-0,fy,fx-0,ty );
	n_bmp_line_reverse( bmp, bmp_onoff, fx-1,fy,fx-1,ty );

	// Right
	n_bmp_line_reverse( bmp, bmp_onoff, tx+0,fy,tx+0,ty );
	n_bmp_line_reverse( bmp, bmp_onoff, tx+1,fy,tx+1,ty );


	return;
}

u32
n_bmp_checker_pixel( n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 color )
{

	// [!] : ( n & 31 ) == ( n % 32 )


	n_type_gfx mod_sx = ( sx & 31 ) / 2;
	n_type_gfx mod_sy = ( sy & 31 ) / 2;

	x -= mod_sx;
	y -= mod_sy;


	n_type_gfx mod_x = ( x & 31 );
	n_type_gfx mod_y = ( y & 31 );

	if (
		( ( 16 >  mod_x )&&( 16 >  mod_y ) )
		||
		( ( 16 <= mod_x )&&( 16 <= mod_y ) )
	)
	{
		n_type_real ratio = 0.75;//n_bmp_blend_alpha2ratio( color );
		color = n_bmp_blend_pixel( n_bmp_white, color, ratio );
	}


	return color;
}

void
n_draw_line( n_bmp *bmp, n_type_gfx fx, n_type_gfx fy, n_type_gfx tx, n_type_gfx ty, u32 color, n_type_gfx circle_step, n_type_gfx real_step )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_real step = 0;
	n_type_real unit = (n_type_real) abs( fy - ty ) / n_posix_max_n_type_gfx( 1, abs( fx - tx ) );


	n_type_gfx full = circle_step;
	n_type_gfx half = real_step / 2;


	n_type_gfx i = 0;
	n_posix_loop
	{

		// [!] : need to draw the first pos

		if ( ( i == 0 )||( 0 == ( i % full ) ) )
		{
			n_bmp_circle( bmp, fx - half, fy - half, full, full, color );
		}


		// [!] : need to draw tx,ty once or more

		if ( ( fx == tx )&&( fy == ty ) ) { break; }


		// [!] : don't use "else" : avoid zig-zag

		if ( step < 1 )
		{
			step += unit;
			if ( fx > tx ) { fx--; } else if ( fx < tx ) { fx++; }
		}

		if ( step >= 1 )
		{
			step -= 1;
			if ( fy > ty ) { fy--; } else if ( fy < ty ) { fy++; }
		}


		i++;

	}


	return;
}

void
n_draw_frame( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 fg, u32 bg )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx fx  = x;
	n_type_gfx fy  = y;
	n_type_gfx tx  = x + sx - 1;
	n_type_gfx ty  = y + sy - 1;


	// Top
	n_bmp_line_dot( bmp, fx,fy,tx,fy, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,tx,fy, bg, 2 );

	// Bottom
	n_bmp_line_dot( bmp, fx,ty,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,ty,tx,ty, bg, 2 );


	fy++;
	ty--;

	// Left
	n_bmp_line_dot( bmp, fx,fy,fx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,fx,ty, bg, 2 );

	// Right
	n_bmp_line_dot( bmp, tx,fy,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, tx,fy,tx,ty, bg, 2 );


	return;
}

void
n_draw_gdi_box( HDC hdc, n_type_gfx fx, n_type_gfx fy, n_type_gfx tx, n_type_gfx ty, HGDIOBJ hb )
{

	RECT r = { fx,fy,tx,ty };


	FillRect( hdc, &r, hb );
	ExcludeClipRect( hdc, fx,fy,tx,ty );


	return;
}

void
n_draw_gdi_frame2canvas( HDC hdc, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, RECT r, COLORREF fg, COLORREF bg )
{

	n_type_gfx size = 2;

	n_type_gfx fx,tx,fy,ty;


	HGDIOBJ hb_fg = CreateSolidBrush( fg );
	HGDIOBJ hb_bg = CreateSolidBrush( bg );


	// [!] : Top / Bottom

	fx = x - size;
	tx = x + sx;
	fy = y - size;
	ty = y + sy;

	n_posix_loop
	{

		POINT pt_u = { fx, fy };
		POINT pt_d = { fx, ty };

		if ( PtInRect( &r, pt_u ) )
		{
			n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_fg );
		}
		if ( PtInRect( &r, pt_d ) )
		{
			n_draw_gdi_box( hdc, fx, ty, fx + size, ty + size, hb_fg );
		}

		fx += size;

		if ( PtInRect( &r, pt_u ) )
		{
			n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_bg );
		}
		if ( PtInRect( &r, pt_d ) )
		{
			n_draw_gdi_box( hdc, fx, ty, fx + size, ty + size, hb_bg );
		}

		fx += size;

		if ( fx >= tx ) { break; }
	}


	// [!] : Left / Right

	fx = x - size;
	tx = x + sx;
	fy = y - size;
	ty = y + sy;

	n_posix_loop
	{//break;

		POINT pt_l = { fx, fy };
		POINT pt_r = { tx, fy };

		if ( PtInRect( &r, pt_l ) ) { n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_fg ); }
		if ( PtInRect( &r, pt_r ) ) { n_draw_gdi_box( hdc, tx, fy, tx + size, fy + size, hb_fg ); }

		fy += size;

		if ( PtInRect( &r, pt_l ) ) { n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_bg ); }
		if ( PtInRect( &r, pt_r ) ) { n_draw_gdi_box( hdc, tx, fy, tx + size, fy + size, hb_bg ); }

		fy += size;

		if ( fy >= ty ) { break; }
	}


	DeleteObject( hb_fg );
	DeleteObject( hb_bg );


	return;
}

void
n_draw_gdi_clear( HDC hdc, HWND hwnd, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	HBRUSH hb = CreateSolidBrush( color );
	RECT   r;   GetClientRect( hwnd, &r );

	FillRect( hdc, &r, hb );

	DeleteObject( hb );


	return;
}

void
n_draw_gdi_clear_simple( HWND hwnd, COLORREF color )
{

	HDC hdc = GetDC( hwnd );

	n_draw_gdi_clear( hdc, hwnd, color );

	ReleaseDC( hwnd, hdc );


	return;
}

void
n_draw_gdi_mask( HDC hdc, HWND hgui )
{

	n_type_gfx x,y,sx,sy;
	n_win_location( hgui, &x, &y, &sx, &sy );

	ExcludeClipRect( hdc, x, y, x + sx, y + sy );


	return;
}

