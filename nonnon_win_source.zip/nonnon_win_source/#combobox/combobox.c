// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"


#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_combobox.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_combo combo;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_game_timegettime_init();

		n_project_darkmode();


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_combo_zero( &combo );
		n_win_combo_init( &combo, hwnd );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		{

			int count = 5;

			n_txt_set( &combo.txt, 0, n_posix_literal( "Text 0" ) );
			n_txt_set( &combo.txt, 1, n_posix_literal( "Text 1" ) );
			n_txt_set( &combo.txt, 2, n_posix_literal( "Text 2" ) );
			n_txt_set( &combo.txt, 3, n_posix_literal( "Text 3" ) );
			n_txt_set( &combo.txt, 4, n_posix_literal( "Text 4" ) );
			n_txt_set( &combo.txt, 5, n_posix_literal( "Text 5" ) );
			n_txt_set( &combo.txt, 6, n_posix_literal( "Text 6" ) );
			n_txt_set( &combo.txt, 7, n_posix_literal( "Text 7" ) );
			n_txt_set( &combo.txt, 8, n_posix_literal( "Text 8" ) );
			n_txt_set( &combo.txt, 9, n_posix_literal( "Text 9" ) );

			n_win_combo_selection_set( &combo, 5 );

			n_type_gfx desktop_size; n_win_desktop_size( &desktop_size, NULL );

			n_type_gfx csx = (n_type_gfx) ( (n_type_real) desktop_size * 0.2 );
			n_type_gfx csy = csx;

			n_win_set( hwnd, NULL, csx,csy, N_WIN_SET_CENTERING );

			n_type_gfx ctl; n_win_stdsize( combo.input.hwnd, &ctl, NULL, NULL );

			n_type_gfx sx = (n_type_gfx) ( (n_type_real) csx * 0.5 );
			n_type_gfx sy = ctl;

			n_type_gfx center_x = ( csx - sx ) / 2;
			n_type_gfx center_y = ( csy - sy ) / 2;

			n_win_combo_move( &combo, center_x, center_y, sx, count, n_true );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{
		} else
		if ( wparam == VK_F2 )
		{
		} else
		if ( wparam == VK_F3 )
		{
		} else
		if ( wparam == VK_F4 )
		{
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_combo_exit( &combo );

		n_game_timegettime_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &combo );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


