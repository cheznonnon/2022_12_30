// Nonnon Project Checker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/string_path.c"
#include "../nonnon/neutral/time.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_filer.c"
#include "../nonnon/win32/win_radiobutton.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"




// rc.h

//#define N_PC_DEBUG_SLOW


#define N_PC_APPNAME "Nonnon Project Checker"

#define N_PC_MSG_F   n_posix_literal( "From" )
#define N_PC_MSG_T   n_posix_literal( "To"   )


#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_PROJECTCHECKER ( 0 )

#endif // #ifndef NONNON_APPS


#define N_PC_MSEC  ( 100 )

#define n_project_string_working    n_posix_literal( "Working" )




typedef struct {

	n_win_radio      radio_f;
	n_win_radio      radio_t;

	n_win_txtbox     label_f;
	n_win_txtbox     label_t;

	n_win_button     btn_rev;
	n_win_button     btn_go;

	n_win_txtbox     txtbox;

	n_type_gfx       minwsx,minwsy;

	n_bool           complete_onoff;

	UINT             timer_id;

	WNDPROC          flickerfree_func;

	n_win_simplemenu simplemenu;
	n_win_titlemenu  titlemenu;

} n_projectchecker;


static n_projectchecker pc;




n_bool
n_pc_is_file( const n_posix_char *f, const n_posix_char *t )
{

	if (
		( N_POSIX_STAT_TYPE_FILE == n_posix_stat_type( f ) )
		&&
		( N_POSIX_STAT_TYPE_FILE == n_posix_stat_type( t ) )
	)
	{
		return n_true;
	}


	return n_false;
}

n_bool
n_pc_is_folder( const n_posix_char *f, const n_posix_char *t )
{

	if (
		( N_POSIX_STAT_TYPE_DIRECTORY == n_posix_stat_type( f ) )
		&&
		( N_POSIX_STAT_TYPE_DIRECTORY == n_posix_stat_type( t ) )
	)
	{
		return n_true;
	}


	return n_false;
}

void
n_pc_go_file( const n_posix_char *f, const n_posix_char *t )
{

	n_win_txtbox_reset( &pc.txtbox );

	if ( n_filer_is_same( f, t ) )
	{
		n_win_txtbox_line_add( &pc.txtbox, 0, n_posix_literal(      "Same Binary" ) );
		return;
	} else {
		n_win_txtbox_line_add( &pc.txtbox, 0, n_posix_literal( "Different Binary" ) );
	}


	n_type_int diff_line = -1;


	n_posix_bool ret = n_posix_false;

	n_txt txt_f; n_txt_zero( &txt_f ); ret |= n_txt_load( &txt_f, f );
	n_txt txt_t; n_txt_zero( &txt_t ); ret |= n_txt_load( &txt_t, t );

	if ( ret )
	{
		n_txt_free( &txt_f );
		n_txt_free( &txt_t );

		return;
	}

	if (
		( txt_f.newline == N_TXT_NEWLINE_BINARY )
		||
		( txt_t.newline == N_TXT_NEWLINE_BINARY )
	)
	{
		n_txt_free( &txt_f );
		n_txt_free( &txt_t );

		return;
	}

	n_type_int i = 0;
	n_posix_loop
	{
		if ( ( i >= txt_f.sy )&&( i >= txt_t.sy ) ) { break; }

		if ( i >= txt_f.sy ) { diff_line = i; break; }
		if ( i >= txt_t.sy ) { diff_line = i; break; }

		if ( n_string_is_same( n_txt_get( &txt_f, i ), n_txt_get( &txt_t, i ) ) )
		{
			//
		} else {
			diff_line = i;
			break;
		}

		i++;
	}


	if ( diff_line != -1 )
	{
		n_posix_char str_line[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_line, 1 + diff_line );

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "Line #%s", str_line );

		n_win_txtbox_line_add( &pc.txtbox, 1, str );
	}

	n_txt_free( &txt_f );
	n_txt_free( &txt_t );


	return;
}

// internal
void
n_pc_go_throbber( int phase )
{

	int           cch = 7;
	n_posix_char *str = n_string_alloccopy( cch + 3, n_project_string_working );

	int i = 0;
	n_posix_loop
	{

		if ( i >= phase ) { break; }

		cch += n_posix_sprintf_literal( &str[ cch ], "%s", N_STRING_DOT );

		i++;

	}

	n_txt_mod_fast( &pc.txtbox.txt, 0, str );
	n_win_message_send( pc.txtbox.hwnd, WM_PAINT, 0,0 );


	return;
}

// internal
n_type_int
n_pc_go_folder_count( const n_posix_char *folder, n_bool is_first )
{

	const  u32        msec  = 250;

	static n_type_int count = 0;
	static u32        timer = 0;
	static int        phase = 0;

	if ( is_first )
	{
		count = 0;
		timer = n_posix_tickcount() + msec;
		phase = 0;
		n_pc_go_throbber( phase );
	}


	n_posix_DIR *dp = n_posix_opendir_nodot( folder );
	if ( dp == NULL ) { return 0; }


	n_posix_char *curdir = n_string_path_folder_current_new();
	n_string_path_folder_change_fast( folder );


	n_posix_loop
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		if ( FILE_ATTRIBUTE_DIRECTORY & dirent->dwFileAttributes )
		{
			n_pc_go_folder_count( dirent->d_name, n_false );
		}


		if ( timer < n_posix_tickcount() )
		{

			timer = n_posix_tickcount() + msec;

			phase++;
			if ( phase >= 4 ) { phase = 0; }

			n_pc_go_throbber( phase );

		}


		count++;

#ifdef N_PC_DEBUG_SLOW
		n_posix_sleep( 1000 );
#endif // #ifdef N_PC_DEBUG_SLOW

	}


	n_string_path_folder_change_fast( curdir );
	n_string_path_free( curdir );


	n_posix_closedir( dp );

/*
	if ( ( is_first )&&( phase != 0 ) )
	{

		n_posix_loop
		{//break;

			if ( timer < n_posix_tickcount() )
			{

				timer = n_posix_tickcount() + msec;

				phase++;
				if ( phase >= 4 ) { break; }

				n_pc_go_throbber( phase );

			}

#ifdef N_PC_DEBUG_SLOW
		n_posix_sleep( 1000 );
#endif // #ifdef N_PC_DEBUG_SLOW

		}

	}
*/

	return count;
}

// internal
void
n_pc_go_folder_count_warm_up( const n_posix_char *folder, n_bool is_first )
{

	const  u32 msec  = 100;
	static u32 timer = 0;

	if ( is_first )
	{
		timer = n_posix_tickcount() + msec;
	}


	//static u32 level = 0;


	n_posix_DIR *dp = n_posix_opendir_nodot( folder );
	if ( dp == NULL ) { return; }


	n_posix_char *curdir = n_string_path_folder_current_new();
	n_string_path_folder_change_fast( folder );


	n_posix_loop
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		if ( FILE_ATTRIBUTE_DIRECTORY & dirent->dwFileAttributes )
		{
			//if ( level == 0 )
			{
//n_posix_debug_literal( "%s", dirent->d_name );
				//level++;
				n_pc_go_folder_count_warm_up( dirent->d_name, n_false );
				//level--;
			}
		}


		if ( timer < n_posix_tickcount() )
		{
			break;
		}

	}


	n_string_path_folder_change_fast( curdir );
	n_string_path_free( curdir );


	n_posix_closedir( dp );


	return;
}

void
n_pc_go_folder( const n_posix_char *f, const n_posix_char *t, n_bool complete_onoff, n_bool is_first )
{

	if ( n_string_is_same( f, t ) ) { return; }


	n_dir d; n_dir_zero( & d );
	if ( n_dir_load( &d, t ) ) { return; }

	if ( 0 >= n_dir_all( &d ) ) { n_dir_free( &d ); return; }


	n_dir_sort_path( &d );


	static n_posix_char *toplevel;
	static n_txt         txt;
	static n_type_real   step;
	static n_type_real   percent_prv;
	static n_type_real   percent_cur;

	//const  u32           msec = 100;
	//static u32           timer;

	if ( is_first )
	{
		toplevel = n_string_path_carboncopy( f );

		n_txt_zero( &txt ); n_txt_new( &txt );

		n_type_int count = n_pc_go_folder_count( t, n_true );

		step        = (n_type_real) 100 / count;
		percent_prv = -1;
		percent_cur =  0;

		//timer = n_posix_tickcount() + msec;
	}


	const n_type_int slash = n_posix_strlen( N_POSIX_SLASH );
	const n_type_int f_cch = n_posix_strlen( f ) + slash;
	const n_type_int t_cch = n_posix_strlen( t ) + slash;

	n_posix_structstat f_stat;
	n_posix_structstat t_stat;

	n_type_int i = 0;
	n_posix_loop
	{

		if ( i >= n_dir_all( &d ) ) { break; }


		n_type_int cch_name = n_posix_strlen( n_dir_name( &d, i ) );

		n_posix_char *f_name = n_string_path_new( f_cch + cch_name );
		n_posix_char *t_name = n_string_path_new( t_cch + cch_name );

		n_string_path_make( f, n_dir_name( &d, i ), f_name );
		n_string_path_make( t, n_dir_name( &d, i ), t_name );


		n_bool is_plus = n_false;


		n_bool f_is_exist = ( 0 == n_posix_stat( f_name, &f_stat ) );
		n_bool t_is_exist = ( 0 == n_posix_stat( t_name, &t_stat ) );

		if ( ( t_is_exist )&&( n_false == f_is_exist ) )
		{

			is_plus = n_true;

			n_posix_char *str = n_string_path_cat( n_posix_literal( "+ : " ), t_name, NULL );

			n_txt_set( &txt, txt.sy, str );

			n_string_path_free( str );

		} else
		if (
			( t_is_exist )
			&&
			( n_false == S_ISDIR( f_stat.st_mode ) )
			&&
			( n_false == S_ISDIR( t_stat.st_mode ) )
		)
		{

			// [!] : modified time is different

			if ( ( complete_onoff )&&( n_false == n_filer_is_same( f_name, t_name ) ) )
			{

				n_posix_char *str = n_string_path_cat( n_posix_literal( "? : " ), t_name, NULL );

				n_txt_set( &txt, txt.sy, str );

				n_string_path_free( str );

			} else
			if ( n_time_compare_mtime( f_name, t_name ) )
			{

				n_posix_char *str = n_string_path_cat( n_posix_literal( "! : " ), t_name, NULL );

				n_txt_set( &txt, txt.sy, str );

				n_string_path_free( str );

			}

		}


		if ( ( is_plus == n_false )&&( S_ISDIR( f_stat.st_mode ) ) )
		{
			n_pc_go_folder( f_name, t_name, complete_onoff, n_false );
		}


		n_string_path_free( f_name );
		n_string_path_free( t_name );


		percent_cur += step;
		if (
			//( timer < n_posix_tickcount() )
			//&&
			( trunc( percent_prv ) != trunc( percent_cur ) )
		)
		{
			//timer = n_posix_tickcount() + msec;

			n_posix_char str[ 100 ];
			n_posix_sprintf_literal( str, "%s (%d%%)", n_project_string_working, (int) trunc( percent_cur ) );
			n_win_txtbox_line_mod( &pc.txtbox, 0, str );
			n_win_message_send( pc.txtbox.hwnd, WM_PAINT, 0,0 );
		}
		percent_prv = percent_cur;

		i++;

#ifdef N_PC_DEBUG_SLOW
		n_posix_sleep( 100 );
#endif // #ifdef N_PC_DEBUG_SLOW

	}

	n_dir_free( &d );


	if ( n_string_is_same( f, toplevel ) )
	{
		n_string_path_free( toplevel );

		n_txt_copy( &txt, &pc.txtbox.txt );
		n_txt_free( &txt );
	}


	return;
}

// internal
void
n_pc_sort( void )
{

	if ( pc.txtbox.txt.sy <= 1 ) { return; }


	n_type_int count_question    = 0;
	n_type_int count_exclamation = 0;
	n_type_int count_plus        = 0;

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *f = pc.txtbox.txt.line[ i ];

			if ( f[ 0 ] == n_posix_literal( '?' ) )
			{
				count_question++;
			} else
			if ( f[ 0 ] == n_posix_literal( '!' ) )
			{
				count_exclamation++;
			} else
			if ( f[ 0 ] == n_posix_literal( '+' ) )
			{
				count_plus++;
			}// else

			i++;
			if ( i >= pc.txtbox.txt.sy ) { break; }
		}

	}


	n_type_int index_question    = 0;
	n_type_int index_exclamation = count_question;
	n_type_int index_plus        = count_question + count_exclamation;


	n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = pc.txtbox.txt.line[ i ];
			if ( s[ 0 ] == n_posix_literal( '?' ) )
			{
				n_txt_set( &txt, index_question, s ); index_question++;
			}

			i++;
			if ( i >= pc.txtbox.txt.sy ) { break; }
		}

	}

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = pc.txtbox.txt.line[ i ];
			if ( s[ 0 ] == n_posix_literal( '!' ) )
			{
				n_txt_set( &txt, index_exclamation, s ); index_exclamation++;
			}

			i++;
			if ( i >= pc.txtbox.txt.sy ) { break; }
		}

	}

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = pc.txtbox.txt.line[ i ];
			if ( s[ 0 ] == n_posix_literal( '+' ) )
			{
				n_txt_set( &txt, index_plus, s ); index_plus++;
			}

			i++;
			if ( i >= pc.txtbox.txt.sy ) { break; }
		}

	}

	n_txt_free( &pc.txtbox.txt );
	n_txt_alias( &txt, &pc.txtbox.txt );


	return;
}

// internal
void
n_pc_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );

	n_type_gfx pad = m;


	static n_bool is_first = n_true;


	int nwset = N_WIN_SET_DEFAULT;

	n_type_gfx csx = -1;
	n_type_gfx csy = -1;

	if ( is_first )
	{

		is_first = n_false;

		nwset = N_WIN_SET_CENTERING;

		pc.minwsy = csy = pad + ( ctl * 2 ) + ( ctl * 7 ) + ( ctl * 1 );
		pc.minwsx = csx = pad + (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) );

	} else {

		nwset = n_project_n_win_set();

	}


	n_win w;
	n_win_set( hwnd, &w, csx,csy, nwset );

	csx = w.csx - ( pad * 2 );
	csy = w.csy - ( pad * 2 );
	

	n_type_gfx dpi   = n_win_dpi( hwnd );
	n_type_gfx radio = ctl * 3;
	n_type_gfx label = csx - radio - ico - ( m * 2 );
	n_type_gfx list  = csy - ( ctl * 3 );
	n_type_gfx rsx   = ico; if ( dpi != 96 ) { rsx -= ( dpi / 96 ); }
	n_type_gfx rsy   = ( ctl * 2 ) - m;

	n_type_gfx x = pad;
	n_type_gfx y = pad;

	n_type_gfx q  = m;
	n_type_gfx qq = q;

	n_win_move       (  pc.radio_f.hwnd,             x,           y,  radio,    ctl, redraw );
	n_win_move       (  pc.radio_t.hwnd,             x,       ctl+y,  radio,    ctl, redraw );
	n_win_move       (  pc.label_f.hwnd,       radio+x,          +y,  label,    ctl, redraw );
	n_win_move       (  pc.label_t.hwnd,       radio+x,       ctl+y,  label,    ctl, redraw );
	n_win_button_move( &pc.btn_rev     , csx-ico-1+x-q,       m+y-q, rsx+qq, rsy+qq, redraw );
	n_win_move       (  pc.txtbox .hwnd,           1+x,     2*ctl+y,  csx-2,   list, redraw );
	n_win_button_move( &pc.btn_go      ,             x,   csy-ctl+y,  csx  ,    ctl, redraw );


	//n_win_refresh( hwnd, n_true );


	return;
}

void
n_pc_icon_add( void )
{

	n_win_icon_init_callback = n_project_system_icon_color;

	{
		n_posix_char *exe = n_win_exepath_new();

		pc.btn_rev.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_PROJECTCHECKER + 1, N_WIN_ICON_INIT_OPTION_RESOURCE );

		n_string_path_free( exe );
	}


	return;
}

void
n_pc_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_pc_icon_add();

		n_win_radio_on_settingchange( &pc.radio_f );
		n_win_radio_on_settingchange( &pc.radio_t );

		n_win_button_on_settingchange( &pc.btn_rev );
		n_win_button_on_settingchange( &pc.btn_go  );

		n_win_txtbox_on_settingchange( &pc.label_f );
		n_win_txtbox_on_settingchange( &pc.label_t );
		n_win_txtbox_on_settingchange( &pc.txtbox  );

		n_pc_resize( hwnd );

	break;


	} // switch


}

LRESULT CALLBACK
n_pc_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_pc_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_bmp_safemode = n_bmp_safemode_base = n_false;

		n_win_exedir2curdir();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_win_ime_disable( hwnd );


		n_memory_zero( &pc, sizeof( n_projectchecker ) );


		// Window

		n_win_init_literal( hwnd, N_PC_APPNAME, "PC_0_MAIN", "" );

		n_win_radio_init( &pc.radio_f, hwnd, N_PC_MSG_F, RBS_CHECKEDNORMAL   );
		n_win_radio_init( &pc.radio_t, hwnd, N_PC_MSG_T, RBS_UNCHECKEDNORMAL );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;
			option |= N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON;

			n_win_txtbox_init( &pc.label_f, hwnd, style, option );
			n_win_txtbox_init( &pc.label_t, hwnd, style, option );

			n_win_txtbox_grayed( &pc.label_f, n_true );
			n_win_txtbox_grayed( &pc.label_t, n_true );
		}

		n_win_button_init( &pc.btn_rev, hwnd,      N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &pc.btn_go , hwnd, n_project_string_go, PBS_NORMAL );

		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int option = 0;

			if ( n_win_fluent_ui_onoff )
			{
				option = option | N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
			}

			n_win_txtbox_zero( &pc.txtbox );
			n_win_txtbox_init( &pc.txtbox, hwnd, style, option );

		}


//n_win_hwndprintf_literal( H_LABEL1, "Z:\\c2" );
//n_win_hwndprintf_literal( H_LABEL2, "Z:\\c" );


		// Style

		n_project_window_resizable( hwnd );

		pc.label_f.txt.readonly = n_true;
		pc.label_t.txt.readonly = n_true;

		n_pc_icon_add();

		n_win_flickerfree_init( hwnd, &pc.flickerfree_func );
		n_win_flickerfree_win_iconbutton_init( pc.btn_rev.hwnd );
		n_win_flickerfree_win_iconbutton_init( pc.btn_go .hwnd );


		n_win_simplemenu_zero( &pc.simplemenu );
		n_win_simplemenu_init( &pc.simplemenu );

		n_win_simplemenu_set( &pc.simplemenu, 0, NULL, n_posix_literal( "[ ]Complete Mode" ), NULL );

		n_win_titlemenu_init_main( &pc.titlemenu, hwnd, &pc.simplemenu );


		// Size

		n_pc_resize( hwnd );


		// Init

		{

			n_posix_char *cmdline = n_win_commandline_new();


#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_PROJECTCHECKER, cmdline );

#endif // #ifdef NONNON_APPS


			if ( n_string_is_empty( cmdline ) )
			{
				n_win_radio_check( &pc.radio_f );
			} else {
				n_win_radio_check( &pc.radio_t );

				n_win_txtbox_line_mod( &pc.label_f, 0, cmdline );
				n_win_txtbox_select_tail_set( &pc.label_f );
			}

			n_win_txtbox_refresh( &pc.label_f, N_WIN_TXTBOX_PROJECTCHECKER );


			n_string_path_free( cmdline );

		}


		n_win_txtbox_line_add( &pc.txtbox, 0, n_project_string_drophere );
		n_win_txtbox_refresh( &pc.txtbox, N_WIN_TXTBOX_PROJECTCHECKER );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;

	case WM_SIZE :

		n_pc_resize( hwnd );

	break;

	case WM_SETFOCUS :

		SetFocus( pc.txtbox.hwnd );

	break;

	case WM_DROPFILES :
	{

		n_posix_char *cmdline = n_win_dropfiles_multiple_new( hwnd, wparam );

		//n_pc_go_folder_count_warm_up( cmdline, n_true );

		if ( n_win_radio_is_checked( &pc.radio_f ) )
		{

			n_win_radio_check  ( &pc.radio_t );
			n_win_radio_uncheck( &pc.radio_f );

			n_win_txtbox_line_mod( &pc.label_f, 0, cmdline );
			n_win_txtbox_select_tail_set( &pc.label_f );

			n_win_txtbox_refresh( &pc.label_f, N_WIN_TXTBOX_PROJECTCHECKER );

		} else {

			n_win_radio_check  ( &pc.radio_f );
			n_win_radio_uncheck( &pc.radio_t );

			n_win_txtbox_line_mod( &pc.label_t, 0, cmdline );
			n_win_txtbox_select_tail_set( &pc.label_t );

			n_win_txtbox_refresh( &pc.label_t, N_WIN_TXTBOX_PROJECTCHECKER );

		}

		n_string_path_free( cmdline );

	}
	break;

	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;

		if ( h == pc.txtbox.hwnd )
		{

			n_posix_char *item = n_win_txtbox_selection_new( &pc.txtbox );
//n_posix_debug( item ); n_string_path_free( item ); break;

			n_posix_char *f = n_win_txtbox_line_get_new( &pc.label_f, 0 );
			n_posix_char *t = n_win_txtbox_line_get_new( &pc.label_t, 0 );


			n_bool is_plus = n_false;

			if (
				( item[ 0 ] == n_posix_literal( '!' ) )
				||
				( item[ 0 ] == n_posix_literal( '?' ) )
			)
			{
				is_plus = n_false;
			} else
			if ( item[ 0 ] == n_posix_literal( '+' ) )
			{
				is_plus = n_true;
			} else {

				n_string_path_free( item );

				n_string_path_free( f );
				n_string_path_free( t );

				break;
			}


			// [!] : don't use n_string_path_name()
			//
			//	this will be relative path

			n_posix_char *name = n_string_path_carboncopy( item );

			n_string_copy( &item[ 4 ], item );
			n_string_copy( &item[ n_posix_strlen( t ) ], name );


			n_posix_char *f2 = n_string_path_cat( f, name, NULL );
			n_posix_char *t2 = n_string_path_cat( t, name, NULL );

			n_string_path_free( f ); f = f2;
			n_string_path_free( t ); t = t2;
//n_posix_debug_literal( "%s\n%s", f, t ); break;

//n_posix_debug_literal( "%d %d", n_posix_stat_is_exist( f ), n_posix_stat_is_exist( t ) );

			if ( wparam == WM_LBUTTONDBLCLK )
			{

				n_bool is_cancelled = n_false;
				n_bool is_break     = n_false;

				if ( is_plus )
				{

					if ( n_win_is_input( VK_CONTROL ) )
					{
						if ( n_win_filer_delete ( hwnd, t, &is_cancelled ) ) { is_break = n_true; }
					} else {
						n_explorer_recyclebin( hwnd, t );
					}

				} else {

					if ( n_win_filer_replace( hwnd, f, t, &is_cancelled ) ) { is_break = n_true; }

				}


				if ( is_break )
				{
					n_string_path_free( f );
					n_string_path_free( t );
					break;
				}

				// [!] : succeeded

				if ( is_cancelled ) { break; }

				n_win_txtbox_selection_del( &pc.txtbox );
				n_win_txtbox_unselect( &pc.txtbox );

				n_win_txtbox_refresh( &pc.txtbox, N_WIN_TXTBOX_PROJECTCHECKER );

			} else
			if ( wparam == WM_MBUTTONDBLCLK )
			{

				// [!] : move to an upper folder when not exist

				n_posix_loop
				{

					if ( n_posix_stat_is_exist( f ) ) { break; }

					n_posix_char *f2 = n_string_path_upperfolder_new( f );
					n_string_path_free( f ); f = f2;

					if ( n_string_is_same( f, item ) ) { break; }

				}

				n_explorer_open( f, SW_NORMAL );
				n_explorer_open( t, SW_NORMAL );

			} else
			if ( wparam == WM_RBUTTONDBLCLK )
			{

				n_type_gfx desktop_sy; n_win_desktop_size( NULL, &desktop_sy );
				n_type_gfx orangecat_sy = (n_type_gfx) ( (n_type_real) GetSystemMetrics( SM_CYMAXIMIZED ) * 0.4 );

				n_type_gfx upper_x = ( ( desktop_sy / 2 ) - orangecat_sy ) / 2;
				n_type_gfx lower_x = ( desktop_sy / 2 ) + upper_x;

				n_posix_char *exe_f = n_string_path_new( 100 + n_posix_strlen( f ) );
				n_posix_char *exe_t = n_string_path_new( 100 + n_posix_strlen( t ) );

				n_posix_char *orangecat = n_posix_literal( "orangecat.exe" );
				if ( n_posix_stat_is_exist( orangecat ) )
				{
					//orangecat = n_posix_literal( "orangecat.exe" );
				} else {
					orangecat = n_posix_literal( "nonnonapps.exe -orangecat" );
				}

				n_posix_char str_lower[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_lower, lower_x );
				n_posix_char str_upper[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_upper, upper_x );

				if ( is_plus )
				{

					n_posix_sprintf_literal( exe_f, "%s -folder_as_item -link:off -set:-1,%s,-1,-1 \"%s\"", orangecat, str_lower, f );
					n_posix_sprintf_literal( exe_t, "%s -folder_as_item -link:off -set:-1,%s,-1,-1 \"%s\"", orangecat, str_upper, t );

				} else {

					n_posix_loop
					{

						if ( n_posix_stat_is_exist( f ) ) { break; }

						n_posix_char *f2 = n_string_path_upperfolder_new( f );
						n_string_path_free( f ); f = f2;

						if ( n_string_is_same( f, item ) ) { break; }

					}

					n_posix_sprintf_literal( exe_f, "%s -link:off -set:-1,%s,-1,-1 \"%s\"", orangecat, str_lower, f );
					n_posix_sprintf_literal( exe_t, "%s -link:off -set:-1,%s,-1,-1 \"%s\"", orangecat, str_upper, t );

				}
//n_posix_debug_literal( "%s\n%s", exe_f, exe_t );
//n_posix_debug_literal( "%d %d", n_posix_stat_is_exist( f ), n_posix_stat_is_exist( t ) );


				n_win_exec( exe_f, SW_NORMAL );
				n_win_exec( exe_t, SW_NORMAL );


				n_string_path_free( exe_f );
				n_string_path_free( exe_t );

				n_string_path_free( f );
				n_string_path_free( t );


				SetFocus( pc.txtbox.hwnd );

			}

		} else
		if ( h == pc.btn_rev.hwnd )
		{

			n_posix_char *f = n_win_txtbox_line_get_new( &pc.label_f, 0 );
			n_posix_char *t = n_win_txtbox_line_get_new( &pc.label_t, 0 );

			n_win_txtbox_line_mod( &pc.label_f, 0, t );
			n_win_txtbox_line_mod( &pc.label_t, 0, f );

			n_win_txtbox_select_tail_set( &pc.label_f );
			n_win_txtbox_select_tail_set( &pc.label_t );

			n_win_txtbox_refresh( &pc.label_f, N_WIN_TXTBOX_PROJECTCHECKER );
			n_win_txtbox_refresh( &pc.label_t, N_WIN_TXTBOX_PROJECTCHECKER );

			n_string_path_free( f );
			n_string_path_free( t );

		} else
		if ( h == pc.radio_f.hwnd )
		{
//n_posix_debug_literal( " ! " );

			if ( n_win_radio_is_checked( &pc.radio_f ) )
			{

				n_win_radio_check  ( &pc.radio_f );
				n_win_radio_uncheck( &pc.radio_t );

			}

		} else
		if ( h == pc.radio_t.hwnd )
		{
//n_posix_debug_literal( " ! " );

			if ( n_win_radio_is_checked( &pc.radio_t ) )
			{

				n_win_radio_check  ( &pc.radio_t );
				n_win_radio_uncheck( &pc.radio_f );

			}

		} else
		if ( h == pc.btn_go.hwnd )
		{

			n_project_pleasewait_on( hwnd );


			n_win_txtbox_reset( &pc.txtbox );


			pc.btn_go.keep_on_pressing = n_posix_true;

			n_win_button_forced( &pc.btn_go, PBS_PRESSED );


			// [Patch] : a scroll bar will not be redrawn

			if ( pc.timer_id == 0 ) { pc.timer_id = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, pc.timer_id, N_PC_MSEC );

			return n_posix_true;

		} else
		if ( h == pc.simplemenu.hwnd )
		{
			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
//n_posix_debug_literal( " ! " );
				if ( pc.complete_onoff )
				{
					n_win_simplemenu_tweak_literal( &pc.simplemenu, 0, 'v' );
				} else {
					n_win_simplemenu_tweak_literal( &pc.simplemenu, 0, ' ' );
				}
			} else
			if ( wparam == 0 )
			{
//n_posix_debug_literal( " ! " );
				if ( pc.complete_onoff ) { pc.complete_onoff = n_false; } else { pc.complete_onoff = n_true; }
			}
		}

	}
	break;


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam == pc.timer_id )
		{

			n_posix_char *f = n_win_txtbox_line_get_new( &pc.label_f, 0 );
			n_posix_char *t = n_win_txtbox_line_get_new( &pc.label_t, 0 );

			n_win_cursor_add( NULL, IDC_WAIT );

			if ( n_pc_is_file( f,t ) )
			{

				n_pc_go_file( f,t );

			} else
			if ( n_pc_is_folder( f,t ) )
			{

				n_pc_go_folder( f,t, pc.complete_onoff, n_true );
				n_pc_sort();

			} else {

				n_win_txtbox_reset( &pc.txtbox );
				n_win_txtbox_line_add( &pc.txtbox, 0, n_project_string_error );

			}

			n_win_cursor_add( NULL, IDC_ARROW );

			n_string_path_free( f );
			n_string_path_free( t );


			n_win_txtbox_metrics_canvas( &pc.txtbox );
			n_win_txtbox_refresh( &pc.txtbox, N_WIN_TXTBOX_PROJECTCHECKER );


			pc.btn_go.keep_on_pressing = pc.btn_go.sink_onoff = n_posix_false;

			if ( n_win_is_hovered( pc.btn_go.hwnd ) )
			{
				pc.btn_go.state = PBS_HOT;
			} else {
				pc.btn_go.state = PBS_NORMAL;
			}

			n_win_button_fade_go( &pc.btn_go );


			n_project_pleasewait_off( hwnd );


			n_win_timer_exit( hwnd, pc.timer_id );

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_stdfont_exit( &pc.label_f.hwnd, 1 );
		n_win_stdfont_exit( &pc.label_t.hwnd, 1 );
		n_win_stdfont_exit( &pc.txtbox .hwnd, 1 );

		n_win_radio_exit( &pc.radio_f );
		n_win_radio_exit( &pc.radio_t );

		n_win_txtbox_exit( &pc.txtbox );

		n_win_txtbox_exit( &pc.label_f );
		n_win_txtbox_exit( &pc.label_t );

		n_win_flickerfree_exit( hwnd, &pc.flickerfree_func );
		n_win_flickerfree_win_iconbutton_exit( pc.btn_rev.hwnd );
		n_win_flickerfree_win_iconbutton_exit( pc.btn_go .hwnd );

		n_win_button_exit( &pc.btn_rev );
		n_win_button_exit( &pc.btn_go  );

		n_win_titlemenu_exit( &pc.titlemenu );

		n_win_simplemenu_exit( &pc.simplemenu );

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &pc.label_f );
		if ( ret ) { return ret; }
	}

	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &pc.label_t );
		if ( ret ) { return ret; }
	}

	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &pc.txtbox );
		if ( ret ) { return ret; }
	}


	n_win_radio_proc( hwnd, msg, wparam, lparam, &pc.radio_f );
	n_win_radio_proc( hwnd, msg, wparam, lparam, &pc.radio_t );


	n_win_button_proc( hwnd, msg, wparam, lparam, &pc.btn_rev );
	n_win_button_proc( hwnd, msg, wparam, lparam, &pc.btn_go  );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	n_win_minsize_proc( hwnd, msg, wparam, lparam, pc.minwsx,pc.minwsy );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_pc_wndproc );
}

#endif // #ifndef NONNON_APPS

