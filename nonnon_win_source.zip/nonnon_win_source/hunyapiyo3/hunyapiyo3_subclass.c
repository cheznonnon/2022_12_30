// hunyapiyo3
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win_scroll.c"




LRESULT CALLBACK
n_hunyapiyo3_on_event( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{


	switch( msg ) {


	case WM_SETTINGCHANGE :

		n_hunyapiyo3_on_settingchange( &hunyapiyo3 );

	break;


	case WM_LBUTTONDOWN :

		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_CLCK )
		{
			hunyapiyo3.phase = N_HUNYAPIYO3_PHASE_STRT;

			hunyapiyo3.countdown_font_size = 0;

			extern void n_hunyapiyo3_reset( n_hunyapiyo3* );
			n_hunyapiyo3_reset( &hunyapiyo3 );

			n_game_sound_loop( &hunyapiyo3.snd[ N_HUNYAPIYO3_SOUND_CLICK ] );
		}

	break;

	case WM_MOUSEWHEEL :
	{

		n_type_gfx cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

		n_type_gfx x = cursor_x / hunyapiyo3.unit;
		n_type_gfx y = cursor_y / hunyapiyo3.unit;

		if (
			( ( x >= 0 )&&( x < N_HUNYAPIYO3_MAP_SX ) )
			&&
			( ( y >= 0 )&&( y < N_HUNYAPIYO3_MAP_SY ) )
		)
		{
			int delta = n_win_scroll_wheeldelta( wparam, 1 );
			if ( delta > 0 )
			{
				int ret_pos = x + ( N_HUNYAPIYO3_MAP_SX * y );

				hunyapiyo3.ret[ ret_pos ]++;
				if ( hunyapiyo3.ret[ ret_pos ] >= N_HUNYAPIYO3_RANDOM )
				{
					hunyapiyo3.ret[ ret_pos ] = -1;
				}
			} else
			if ( delta < 0 )
			{
				int ret_pos = x + ( N_HUNYAPIYO3_MAP_SX * y );

				hunyapiyo3.ret[ ret_pos ]--;
				if ( hunyapiyo3.ret[ ret_pos ] < -1 )
				{
					hunyapiyo3.ret[ ret_pos ] = N_HUNYAPIYO3_RANDOM - 1;
				}
			}
		}

	}
	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


