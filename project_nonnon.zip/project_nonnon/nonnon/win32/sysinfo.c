// Nonnon Win32 System Information
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -version




#ifndef _H_NONNON_WIN32_SYSINFO
#define _H_NONNON_WIN32_SYSINFO




#include "./sysinfo/_debug.c"
#include "./sysinfo/cpu.c"
#include "./sysinfo/drive.c"
#include "./sysinfo/fileversion.c"
#include "./sysinfo/memory.c"
#include "./sysinfo/process.c"
#include "./sysinfo/processlist.c"
#include "./sysinfo/sysmon.c"
#include "./sysinfo/version.c"
#include "./sysinfo/version_misc.c"




#endif // _H_NONNON_WIN32_SYSINFO

