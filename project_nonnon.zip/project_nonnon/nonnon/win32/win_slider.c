// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_SLIDER
#define _H_NONNON_WIN32_WIN_SLIDER




#include "./win.c"




#define N_WIN_SLIDER_LAYOUT_VERT ( 0 )
#define N_WIN_SLIDER_LAYOUT_HORZ ( 1 )




typedef struct {

	HWND          hwnd;

	u32           color_accent;
	n_posix_bool  dwm_onoff;

	int           layout;

	RECT          rect_all;
	RECT          rect_shaft;
	RECT          rect_thumb;

	n_posix_bool  dnd_onoff;

	n_bmp         bmp_canvas;
	n_bmp         bmp_shaft;

	int           value;
	int           value_max;

	int           hover_percent;

} n_win_slider;




#define n_win_slider_zero( p ) n_memory_zero( p, sizeof( n_win_slider ) )

void
n_win_slider_exit( n_win_slider *p )
{

	n_bmp_free_fast( &p->bmp_canvas );
	n_bmp_free_fast( &p->bmp_shaft  );


	n_win_slider_zero( p );


	return;
}

void
n_win_slider_init( n_win_slider *p, HWND hwnd_parent, int value_max )
{

	n_win_slider_zero( p );

	n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS, "", &p->hwnd );

	p->value_max = value_max;


	return;
}

void
n_win_slider_on_settingchange( n_win_slider *p, n_posix_bool dwm_onoff, u32 color_accent )
{

	p->dwm_onoff    = dwm_onoff;
	p->color_accent = color_accent;

	n_win_refresh( p->hwnd, n_posix_false );


	return;
}

void
n_win_slider_draw( n_win_slider *p, HDC hdc, RECT *rect )
{
//return;
//n_win_box( p->hwnd, hdc, r, RGB(0,200,255) );

	u32 color_bg = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNFACE   );
	u32 color_sh = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNSHADOW );
	u32 color_pb = p->color_accent;

	if ( p->dwm_onoff ) { color_bg = n_bmp_black_invisible; }


	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	n_bmp_flush( &p->bmp_canvas, color_bg );


	// [!] : shaft

	n_type_gfx bar_sx;
	n_type_gfx bar_sy;

	if ( p->layout == N_WIN_SLIDER_LAYOUT_VERT )
	{
		bar_sx = (n_type_gfx) ( (n_type_real) sx * 0.25 );
		bar_sy = (n_type_gfx) ( (n_type_real) sy * 0.80 );
	} else {
		bar_sx = (n_type_gfx) ( (n_type_real) sx * 0.80 );
		bar_sy = (n_type_gfx) ( (n_type_real) sy * 0.25 );
	}

	n_bmp_flush( &p->bmp_shaft, color_bg );

	n_bmp_roundrect_ratio( &p->bmp_shaft, 0, 0, N_BMP_SX( &p->bmp_shaft ), N_BMP_SY( &p->bmp_shaft ), color_sh, 100 );

	n_type_gfx cx = ( sx - bar_sx ) / 2;
	n_type_gfx cy = ( sy - bar_sy ) / 2;

	//n_bmp_transcopy( &p->bmp_shaft, &p->bmp_canvas, 0,0,bar_sx,bar_sy, cx,cy );


	//if ( 0 )
	{

		// [!] : progress

		n_type_gfx offset;

		if ( p->layout == N_WIN_SLIDER_LAYOUT_VERT )
		{
			n_type_real d = (n_type_real) p->value * ( 1.0 / p->value_max );

			offset = (n_type_gfx) ( (n_type_real) bar_sy * d );

			n_bmp_roundrect_ratio( &p->bmp_shaft, 0, bar_sy - offset, N_BMP_SX( &p->bmp_shaft ), offset, color_pb, 100 );
		} else {
			n_type_real d = (n_type_real) p->value * ( 1.0 / p->value_max );

			offset = (n_type_gfx) ( (n_type_real) bar_sx * d );

			n_bmp_roundrect_ratio( &p->bmp_shaft, 0, 0, offset, N_BMP_SY( &p->bmp_shaft ), color_pb, 100 );
		}

		n_bmp_transcopy( &p->bmp_shaft, &p->bmp_canvas, 0,0,bar_sx,bar_sy, cx,cy );
		n_win_rect_set( &p->rect_shaft, cx,cy,bar_sx,bar_sy );


		// [!] : thumb

		//if ( 0 )
		{

			n_type_gfx sz, tx,ty;

			if ( p->layout == N_WIN_SLIDER_LAYOUT_VERT )
			{
				sz = (n_type_gfx) ( (n_type_real) bar_sx * 3 );

				tx = ( sx - sz ) / 2;
				ty = bar_sy - offset + ( sz / 2 );
			} else {
				sz = (n_type_gfx) ( (n_type_real) bar_sy * 3 );

				tx = offset + ( sz / 2 );
				ty = ( sy - sz ) / 2;
			}


			n_bmp_circle( &p->bmp_canvas, tx,ty,sz,sz, color_sh );

			n_win_rect_set( &p->rect_thumb, tx,ty,sz,sz );


			n_type_gfx border = (n_type_gfx) n_win_scale( p->hwnd );

			tx += border;
			ty += border;
			sz -= border * 2;

			n_bmp_circle( &p->bmp_canvas, tx,ty,sz,sz, n_bmp_white );


			n_type_gfx scale = (n_type_gfx) ( n_win_scale( p->hwnd ) * 3 );

			tx += scale;
			ty += scale;
			sz -= scale * 2;

			u32 color_circle = n_bmp_blend_pixel( color_pb, n_bmp_white, (n_type_real) p->hover_percent * 0.01 * 0.5 );
			n_bmp_circle( &p->bmp_canvas, tx,ty,sz,sz, color_circle );

		}

	}


	n_gdi_bitmap_draw_main( p->hwnd, hdc, &p->bmp_canvas, 0,0,sx,sy, x,y );


	return;
}

void
n_win_slider_move( n_win_slider *p )
{
//return;

	n_type_gfx cursor;
	n_type_gfx f,t;

	if ( p->layout == N_WIN_SLIDER_LAYOUT_VERT )
	{
		n_win_cursor_position_relative( p->hwnd, NULL, &cursor ); 

		n_win_rect_expand_size( &p->rect_shaft, NULL, &f, NULL, &t );
	} else {
		n_win_cursor_position_relative( p->hwnd, &cursor, NULL ); 

		n_win_rect_expand_size( &p->rect_shaft, &f, NULL, &t, NULL );
	}
//n_win_hwndprintf_literal( GetParent( p->hwnd ), "%d %d", f, t );

	n_type_gfx th;

	if ( p->layout == N_WIN_SLIDER_LAYOUT_VERT )
	{
		n_win_rect_expand_size( &p->rect_thumb, NULL, NULL, NULL, &th );
	} else {
		n_win_rect_expand_size( &p->rect_thumb, NULL, NULL, &th, NULL );
	}

	f = cursor - f - ( th / 4 );

	p->value = (int) ( ( (n_type_real) f / t ) * p->value_max );
	p->value = n_posix_minmax( 0, p->value_max, p->value_max - p->value );

	if ( p->layout == N_WIN_SLIDER_LAYOUT_VERT )
	{
		//
	} else {
		p->value = p->value_max - p->value;
	}


	HWND hwnd_parent = GetParent( p->hwnd );

	HDC hdc = GetDC( hwnd_parent );

	n_win_slider_draw( p, hdc, &p->rect_all );

	ReleaseDC( hwnd_parent, hdc );


	return;
}




#endif // _H_NONNON_WIN32_WIN_SLIDER


