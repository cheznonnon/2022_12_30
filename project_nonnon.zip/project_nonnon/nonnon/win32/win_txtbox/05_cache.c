// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_linenumber_cache( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	n_type_gfx sx = p->number_pxl_sx / 6;
	n_type_gfx sy = p->cell_pxl_sy;

	u8 i = 0;
	n_posix_loop
	{

		RECT rect = n_win_rect_set( NULL, 0, 0, sx, sy );
		n_posix_char str[ 2 ] = { n_posix_literal( '0' ) + i, N_STRING_CHAR_NUL };

		HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx, sy );

		SetBkColor  ( hdc, p->color_back_linenum1 );
		SetTextColor( hdc, p->color_text_linenum1 );

		// [Needed] : some glyphs : the last line is no-touched
		n_bmp_flush( &n_gdi_doublebuffer_32bpp_instance.bmp, n_bmp_colorref2argb( p->color_back_linenum1 ) );

		DrawText( hdc, str, 1, &rect, p->drawtext_modes );

		n_bmp_free( &p->bmp_linenumber[ i ] );
		n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &p->bmp_linenumber[ i ] );

//n_posix_char name[ 100 ]; n_posix_sprintf_literal( name, "%s.bmp", str );
//n_bmp_save( &bmp[ i ], name );

		n_gdi_doublebuffer_32bpp_cleanup( &n_gdi_doublebuffer_32bpp_instance );

		i++;
		if ( i >= 10 ) { break; }


	}


	return;
}

// internal
n_bmp*
n_win_txtbox_glyph_cache
(
	n_win_txtbox *p,
	n_posix_char  index,
	n_posix_bool  is_striped,
	n_posix_bool  is_highlighted
)
{
//return NULL;

	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		return NULL;
	}


	n_bmp *bmp;

	if ( is_highlighted )
	{
		bmp = &p->cache_bmp_hilt[ (n_type_int) index ];
	} else
	if ( p->is_grayed )
	{
		bmp = &p->cache_bmp_gray[ (n_type_int) index ];
	} else
	if ( is_striped )
	{
		bmp = &p->cache_bmp_strp[ (n_type_int) index ];
	} else {
		bmp = &p->cache_bmp_main[ (n_type_int) index ];
	}

	if ( NULL != N_BMP_PTR( bmp ) ) { return bmp; }


	n_posix_char str[ 2 ] = { index, N_STRING_CHAR_NUL };

	n_type_gfx sx;
	n_type_gfx sy = p->cell_pxl_sy;

	if ( p->is_font_monospace )
	{
		if ( n_win_txtbox_is_fullwidth( index ) )
		{
			sx = p->size_fullwidth.cx;
		} else {
			sx = p->size_halfwidth.cx;
		}
	} else {
		// [x] : currently broken

		SIZE size = n_win_txtbox_size_text( p, str );
		sx = size.cx;
		sy = size.cy;
	}

	RECT rect = { 0, 0, sx, sy };


	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx, sy );


	COLORREF bg;
	COLORREF fg;

	if ( is_highlighted )
	{
		bg = p->color_back_selected;
		fg = p->color_text_selected;
	} else
	if ( p->is_grayed )
	{
		bg = p->color_back_disabled;
		fg = p->color_text_noselect;
	} else
	if ( is_striped )
	{
		bg = p->color_back_striping;
		fg = p->color_text_noselect;
	} else {
		bg = p->color_back_noselect;
		fg = p->color_text_noselect;
	}

	SetBkColor  ( hdc, bg & 0x00ffffff );
	SetTextColor( hdc, fg & 0x00ffffff );


	// [Needed] : some glyphs : the last line is no-touched
	n_bmp_flush( &n_gdi_doublebuffer_32bpp_instance.bmp, n_bmp_colorref2argb( bg ) );

	DrawText( hdc, str, 1, &rect, p->drawtext_modes | DT_CENTER );


	n_bmp_free( bmp );
	n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, bmp );

//if ( index == n_posix_literal( 'g' ) ) { n_bmp_save_literal( bmp, "g.bmp" ); }


	n_gdi_doublebuffer_32bpp_cleanup( &n_gdi_doublebuffer_32bpp_instance );


	// Debug Center

	//n_bmp_flush( bmp, n_bmp_rgb( 0,200,255 ) );


	return bmp;
}

void
n_win_txtbox_glyph_cache_reset( n_win_txtbox *p )
{
//return;

	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		return;
	}


	n_type_int i = 0;
	n_posix_loop
	{
		n_bmp_free( &p->cache_bmp_main[ i ] );
		n_bmp_free( &p->cache_bmp_strp[ i ] );
		n_bmp_free( &p->cache_bmp_hilt[ i ] );
		n_bmp_free( &p->cache_bmp_gray[ i ] );

		i++;
		if ( i >= p->cache_limit ) { break; }
	}


	return;
}


