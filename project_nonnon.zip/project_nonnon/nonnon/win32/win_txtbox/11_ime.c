// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_ime_watch_color( n_win_txtbox *p )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
	{
		if ( p->ime_onoff )
		{
			p->color_back_selected = p->color___ime_watcher;
		} else {
			p->color_back_selected = p->color_sel_focus__on;
		}
	} else {
		if ( p->ime_onoff )
		{
			p->color_back_selected = p->color_sel_focus__on;
		} else {
			p->color_back_selected = p->color_sel_focus__on;
		}
	}


	// [ Mechanism ]
	//
	//	.color_back_linenum1	background color
	//	.color_back_linenum2	selected color
	//	.color_back_linenum3	indicator color
	//
	//	.color_text_linenum2	selected text color

	n_type_real ratio; if ( n_win_darkmode_onoff ) { ratio = 0.10; } else { ratio = 0.10; }
	p->color_back_striping = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.10 );
	p->color_back_linenum1 = p->color_back_striping;
	p->color_back_linenum2 = n_win_color_blend( p->color_back_linenum1, p->color_back_selected, 0.25 );
	p->color_back_linenum3 = p->color_back_selected;
	p->color_text_linenum2 = n_win_color_blend( p->color_text_noselect, p->color_back_linenum2, 0.50 );

	p->color_text_tab_mark = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.50 );
	p->color_text_eol_mark = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.50 );


	n_win_txtbox_linenumber_cache( p );
	n_win_txtbox_glyph_cache_reset( p );


	return;
}


